# Nexora

Nexora is a demo-mode entertainment lobby inspired by common Asian gaming-site layouts. It is an original brand and implementation. It is **not** a licensed casino and must not be used for real-money wagering until the operator has confirmed:

- applicable licensing
- jurisdictional legality
- provider authorization
- payment-provider approval
- age verification
- required compliance controls

Until then, balances are simulated NXC credits. Demo results are labeled. Provider adapters report genuine credential status instead of inventing live studio connections.

## Stack

- Next.js App Router + TypeScript
- PostgreSQL via Drizzle ORM
- Cookie sessions, scrypt password hashes, double-entry demo ledger

## Demo accounts

| Role | Email | Password |
| --- | --- | --- |
| Player | `player@nexora.play` | `Demo1234!` |
| Super admin | `admin@nexora.play` | `Admin1234!` |
| Support | `support@nexora.play` | `Support1234!` |

Demo promotion codes: `WELCOME100`, `NEXORA50`.

Playable original demo titles: Neon Reels, Pulse Crash, Lucky Dice. Other catalog tiles stay in coming-soon or maintenance until a provider is authorized.

## Environment

Copy from the values below into `.env`. `DATABASE_URL` is required.

```
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db

# Optional provider credentials. Leave unset to keep adapters in missing_credentials.
PRAGMATIC_API_URL=
PRAGMATIC_API_KEY=
PRAGMATIC_API_SECRET=
PRAGMATIC_WEBHOOK_SECRET=
EVOLUTION_API_URL=
EVOLUTION_CASINO_KEY=
EVOLUTION_API_TOKEN=
EVOLUTION_WEBHOOK_SECRET=
SPORTS_API_URL=
SPORTS_API_KEY=
ESPORTS_API_URL=
ESPORTS_API_KEY=

# Optional support destinations. Buttons stay disabled when empty.
WHATSAPP_SUPPORT_URL=
TELEGRAM_SUPPORT_URL=
FACEBOOK_PAGE_URL=
SUPPORT_EMAIL=
SMTP_URL=
```

Never put provider secrets in client code.

## Database

```bash
npx drizzle-kit push
```

The first authenticated or public request seeds categories, providers, fixture sports, promotions, and demo users.

## Scripts

```bash
npm run dev
npm run build
npm run start
node --test tests/platform.test.mjs
```

## Architecture notes

- Provider adapters live in `src/lib/providers.ts` and implement `getProviders`, `syncGames`, `getGameDetails`, `createLaunchSession`, `verifyCallback`, `processWalletTransaction`, and `getProviderHealth`.
- Wallet mutations use row locks and an immutable ledger. The browser cannot prove a payment.
- Webhooks require HMAC signatures. Replays are idempotent. Real-money credits are rejected even when a signature is valid.
- Admin routes check role on the server. Changing a URL does not grant access.
- Sports events are fixture samples with last-updated timestamps until `SPORTS_API_KEY` is provided by a licensed vendor.

## Deployment

1. Provision PostgreSQL and set `DATABASE_URL`.
2. `npx drizzle-kit push`
3. `npm run build && npm run start`
4. Keep `real_money_enabled=false` until legal review is complete. The admin API refuses to enable it.

This project is **not production-ready** for gambling. Complete security review, penetration testing, and licensing before any real-money launch.

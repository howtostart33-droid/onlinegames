import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const stamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
};

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    displayName: text("display_name").notNull(),
    role: text("role").notNull().default("user"),
    status: text("status").notNull().default("active"),
    language: text("language").notNull().default("en"),
    emailVerified: boolean("email_verified").notNull().default(false),
    phoneVerified: boolean("phone_verified").notNull().default(false),
    dateOfBirth: text("date_of_birth"),
    country: text("country"),
    jurisdictionEligible: boolean("jurisdiction_eligible").notNull().default(false),
    ageVerified: boolean("age_verified").notNull().default(false),
    selfExcludedUntil: timestamp("self_excluded_until", { withTimezone: true }),
    coolingOffUntil: timestamp("cooling_off_until", { withTimezone: true }),
    failedLoginAttempts: integer("failed_login_attempts").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    referralCode: text("referral_code").notNull(),
    referredBy: uuid("referred_by"),
    mfaEnabled: boolean("mfa_enabled").notNull().default(false),
    mfaSecretEnc: text("mfa_secret_enc"),
    ...stamps,
  },
  (t) => [
    uniqueIndex("users_email_idx").on(t.email),
    uniqueIndex("users_referral_idx").on(t.referralCode),
    uniqueIndex("users_phone_idx").on(t.phone),
    index("users_role_idx").on(t.role),
    index("users_status_idx").on(t.status),
  ],
);

export const userSessions = pgTable(
  "user_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    userAgent: text("user_agent"),
    ip: text("ip"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("sessions_token_idx").on(t.tokenHash),
    index("sessions_user_idx").on(t.userId),
  ],
);

export const passwordResetTokens = pgTable(
  "password_reset_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("password_reset_token_idx").on(t.tokenHash)],
);

export const gameProviders = pgTable(
  "game_providers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    adapterKey: text("adapter_key").notNull(),
    status: text("status").notNull().default("missing_credentials"),
    healthStatus: text("health_status").notNull().default("unknown"),
    healthMessage: text("health_message"),
    credentialsConfigured: boolean("credentials_configured").notNull().default(false),
    lastHealthCheck: timestamp("last_health_check", { withTimezone: true }),
    lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
    configNote: text("config_note"),
    enabled: boolean("enabled").notNull().default(true),
    ...stamps,
  },
  (t) => [uniqueIndex("providers_code_idx").on(t.code), index("providers_status_idx").on(t.status)],
);

export const gameCategories = pgTable(
  "game_categories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    enabled: boolean("enabled").notNull().default(true),
    legalHold: boolean("legal_hold").notNull().default(false),
    legalNote: text("legal_note"),
    icon: text("icon").notNull().default("grid"),
  },
  (t) => [uniqueIndex("categories_slug_idx").on(t.slug)],
);

export const games = pgTable(
  "games",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    providerId: uuid("provider_id")
      .notNull()
      .references(() => gameProviders.id, { onDelete: "restrict" }),
    categoryId: uuid("category_id")
      .notNull()
      .references(() => gameCategories.id, { onDelete: "restrict" }),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    thumbnailUrl: text("thumbnail_url"),
    description: text("description"),
    status: text("status").notNull().default("coming_soon"),
    isHot: boolean("is_hot").notNull().default(false),
    isNew: boolean("is_new").notNull().default(false),
    isRecommended: boolean("is_recommended").notNull().default(false),
    launchKind: text("launch_kind").notNull().default("none"),
    engineKey: text("engine_key"),
    playCount: integer("play_count").notNull().default(0),
    sortOrder: integer("sort_order").notNull().default(0),
    artHue: integer("art_hue").notNull().default(24),
    ...stamps,
  },
  (t) => [
    uniqueIndex("games_slug_idx").on(t.slug),
    index("games_status_idx").on(t.status),
    index("games_category_idx").on(t.categoryId),
    index("games_provider_idx").on(t.providerId),
    index("games_hot_idx").on(t.isHot),
  ],
);

export const gameFavorites = pgTable(
  "game_favorites",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    gameId: uuid("game_id")
      .notNull()
      .references(() => games.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("favorites_user_game_idx").on(t.userId, t.gameId)],
);

export const recentGames = pgTable(
  "recent_games",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    gameId: uuid("game_id")
      .notNull()
      .references(() => games.id, { onDelete: "cascade" }),
    playedAt: timestamp("played_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("recent_user_idx").on(t.userId, t.playedAt)],
);

export const gameSessions = pgTable(
  "game_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    gameId: uuid("game_id")
      .notNull()
      .references(() => games.id, { onDelete: "restrict" }),
    providerCode: text("provider_code").notNull(),
    mode: text("mode").notNull().default("demo"),
    status: text("status").notNull().default("open"),
    idempotencyKey: text("idempotency_key").notNull(),
    launchedAt: timestamp("launched_at", { withTimezone: true }).notNull().defaultNow(),
    endedAt: timestamp("ended_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("game_sessions_idem_idx").on(t.idempotencyKey),
    index("game_sessions_user_idx").on(t.userId),
  ],
);

export const wallets = pgTable(
  "wallets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    currency: text("currency").notNull().default("NXC"),
    availableCents: integer("available_cents").notNull().default(0),
    status: text("status").notNull().default("active"),
    version: integer("version").notNull().default(0),
    ...stamps,
  },
  (t) => [uniqueIndex("wallets_user_type_idx").on(t.userId, t.type)],
);

export const ledgerAccounts = pgTable(
  "ledger_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    kind: text("kind").notNull(),
  },
  (t) => [uniqueIndex("ledger_accounts_wallet_code_idx").on(t.walletId, t.code)],
);

export const ledgerTransactions = pgTable(
  "ledger_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "restrict" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    type: text("type").notNull(),
    amountCents: integer("amount_cents").notNull(),
    status: text("status").notNull().default("completed"),
    idempotencyKey: text("idempotency_key").notNull(),
    reference: text("reference"),
    actorId: uuid("actor_id"),
    reason: text("reason"),
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("ledger_tx_idem_idx").on(t.idempotencyKey),
    index("ledger_tx_user_idx").on(t.userId, t.createdAt),
    index("ledger_tx_wallet_idx").on(t.walletId),
  ],
);

export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    transactionId: uuid("transaction_id")
      .notNull()
      .references(() => ledgerTransactions.id, { onDelete: "cascade" }),
    accountId: uuid("account_id")
      .notNull()
      .references(() => ledgerAccounts.id, { onDelete: "restrict" }),
    direction: text("direction").notNull(),
    amountCents: integer("amount_cents").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ledger_entries_tx_idx").on(t.transactionId)],
);

export const depositRequests = pgTable(
  "deposit_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "restrict" }),
    amountCents: integer("amount_cents").notNull(),
    status: text("status").notNull().default("completed"),
    mode: text("mode").notNull().default("demo"),
    providerRef: text("provider_ref"),
    reviewNote: text("review_note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("deposits_user_idx").on(t.userId)],
);

export const withdrawalRequests = pgTable(
  "withdrawal_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "restrict" }),
    amountCents: integer("amount_cents").notNull(),
    status: text("status").notNull().default("completed"),
    mode: text("mode").notNull().default("demo"),
    providerRef: text("provider_ref"),
    reviewNote: text("review_note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("withdrawals_user_idx").on(t.userId)],
);

export const providerCallbacks = pgTable(
  "provider_callbacks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    providerCode: text("provider_code").notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    signatureValid: boolean("signature_valid").notNull().default(false),
    processed: boolean("processed").notNull().default(false),
    rejectionReason: text("rejection_reason"),
    payloadHash: text("payload_hash").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("provider_callbacks_idem_idx").on(t.providerCode, t.idempotencyKey)],
);

export const sportsEvents = pgTable(
  "sports_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    sport: text("sport").notNull(),
    league: text("league").notNull(),
    homeTeam: text("home_team").notNull(),
    awayTeam: text("away_team").notNull(),
    startAt: timestamp("start_at", { withTimezone: true }).notNull(),
    status: text("status").notNull().default("upcoming"),
    homeScore: integer("home_score"),
    awayScore: integer("away_score"),
    isLive: boolean("is_live").notNull().default(false),
    suspended: boolean("suspended").notNull().default(false),
    dataSource: text("data_source").notNull().default("fixture"),
    lastUpdatedAt: timestamp("last_updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sports_events_sport_idx").on(t.sport, t.startAt)],
);

export const sportsMarkets = pgTable(
  "sports_markets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventId: uuid("event_id")
      .notNull()
      .references(() => sportsEvents.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    status: text("status").notNull().default("open"),
    selections: jsonb("selections")
      .$type<{ name: string; odds: string; suspended: boolean }[]>()
      .notNull(),
    lastUpdatedAt: timestamp("last_updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sports_markets_event_idx").on(t.eventId)],
);

export const promotions = pgTable(
  "promotions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull(),
    body: text("body").notNull(),
    kind: text("kind").notNull(),
    imageUrl: text("image_url"),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    simulated: boolean("simulated").notNull().default(true),
    enabled: boolean("enabled").notNull().default(true),
    terms: text("terms").notNull(),
    creditCents: integer("credit_cents").notNull().default(0),
    ...stamps,
  },
  (t) => [uniqueIndex("promotions_slug_idx").on(t.slug)],
);

export const promotionCodes = pgTable(
  "promotion_codes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    promotionId: uuid("promotion_id")
      .notNull()
      .references(() => promotions.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    maxRedemptions: integer("max_redemptions").notNull().default(1),
    perUserLimit: integer("per_user_limit").notNull().default(1),
    enabled: boolean("enabled").notNull().default(true),
  },
  (t) => [uniqueIndex("promo_codes_code_idx").on(t.code)],
);

export const promotionRedemptions = pgTable(
  "promotion_redemptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    promotionId: uuid("promotion_id")
      .notNull()
      .references(() => promotions.id, { onDelete: "cascade" }),
    codeId: uuid("code_id").references(() => promotionCodes.id, { onDelete: "set null" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("promo_redemptions_user_idx").on(t.userId, t.promotionId)],
);

export const supportTickets = pgTable(
  "support_tickets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    subject: text("subject").notNull(),
    status: text("status").notNull().default("open"),
    priority: text("priority").notNull().default("normal"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("tickets_user_idx").on(t.userId)],
);

export const supportMessages = pgTable(
  "support_messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ticketId: uuid("ticket_id")
      .notNull()
      .references(() => supportTickets.id, { onDelete: "cascade" }),
    authorId: uuid("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    fromStaff: boolean("from_staff").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ticket_messages_idx").on(t.ticketId, t.createdAt)],
);

export const responsibleGamingLimits = pgTable(
  "responsible_gaming_limits",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    dailyDepositCents: integer("daily_deposit_cents"),
    sessionMinutes: integer("session_minutes"),
    reminderMinutes: integer("reminder_minutes").notNull().default(60),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("rg_limits_user_idx").on(t.userId)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorId: uuid("actor_id"),
    action: text("action").notNull(),
    entity: text("entity").notNull(),
    entityId: text("entity_id"),
    ip: text("ip"),
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_created_idx").on(t.createdAt), index("audit_actor_idx").on(t.actorId)],
);

export const systemSettings = pgTable("system_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const announcements = pgTable("announcements", {
  id: uuid("id").primaryKey().defaultRandom(),
  message: text("message").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const banners = pgTable("banners", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  imageUrl: text("image_url").notNull(),
  href: text("href").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  enabled: boolean("enabled").notNull().default(true),
});

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    body: text("body").notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notifications_user_idx").on(t.userId)],
);

export const vipTiers = pgTable("vip_tiers", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  minWagerCents: integer("min_wager_cents").notNull(),
  rebateBps: integer("rebate_bps").notNull(),
  sortOrder: integer("sort_order").notNull(),
});

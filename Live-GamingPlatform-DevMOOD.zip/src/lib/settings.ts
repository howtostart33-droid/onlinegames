import { db } from "@/db";
import { systemSettings } from "@/db/schema";

export async function getSettingsMap() {
  const rows = await db.select().from(systemSettings);
  return Object.fromEntries(rows.map((row) => [row.key, row.value])) as Record<string, string>;
}

export function socialFrom(settings: Record<string, string>) {
  return {
    whatsapp: settings.whatsapp_url || process.env.WHATSAPP_SUPPORT_URL || "",
    telegram: settings.telegram_url || process.env.TELEGRAM_SUPPORT_URL || "",
    facebook: settings.facebook_url || process.env.FACEBOOK_PAGE_URL || "",
    supportEmail: settings.support_email || process.env.SUPPORT_EMAIL || "",
  };
}

export const PLATFORM = {
  name: "Nexora",
  tagline: "Arena entertainment in demo mode",
  currency: "NXC",
};

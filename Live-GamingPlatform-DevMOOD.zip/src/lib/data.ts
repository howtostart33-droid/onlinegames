import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { announcements, banners, gameCategories, gameProviders } from "@/db/schema";
import { getSessionUser, toPublicUser } from "@/lib/auth";
import { seedIfNeeded } from "@/lib/seed";
import { getSettingsMap, socialFrom } from "@/lib/settings";
import { formatCredits, getDemoWallet } from "@/lib/wallet";
import type { Bootstrap } from "@/lib/types";

export async function getBootstrap(): Promise<Bootstrap> {
  await seedIfNeeded();
  const session = await getSessionUser();
  const settings = await getSettingsMap();
  const [bannerRows, announcementRows, categoryRows, providerRows] = await Promise.all([
    db.select().from(banners).where(eq(banners.enabled, true)).orderBy(asc(banners.sortOrder)),
    db.select().from(announcements).where(eq(announcements.enabled, true)).orderBy(asc(announcements.sortOrder)),
    db.select().from(gameCategories).orderBy(asc(gameCategories.sortOrder)),
    db.select().from(gameProviders).orderBy(asc(gameProviders.name)),
  ]);
  let demoBalance = 0;
  if (session) {
    const wallet = await getDemoWallet(session.user.id);
    demoBalance = wallet?.availableCents ?? 0;
  }
  return {
    user: session ? toPublicUser(session.user) : null,
    demoBalance,
    demoBalanceLabel: formatCredits(demoBalance),
    banners: bannerRows,
    announcements: announcementRows.map((row) => row.message),
    categories: categoryRows,
    providers: providerRows.map((row) => ({
      id: row.id,
      code: row.code,
      name: row.name,
      category: row.category,
      status: row.status,
      healthStatus: row.healthStatus,
      healthMessage: row.healthMessage,
      credentialsConfigured: row.credentialsConfigured,
      lastHealthCheck: row.lastHealthCheck ? row.lastHealthCheck.toISOString() : null,
    })),
    social: socialFrom(settings),
    realMoneyEnabled: settings.real_money_enabled === "true",
    platform: { name: settings.platform_name || "Nexora", demo: true },
  };
}

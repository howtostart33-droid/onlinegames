import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { gameProviders, games, providerCallbacks } from "@/db/schema";
import { sha256, verifyWebhookSignature } from "@/lib/crypto";

export type ProviderCategory =
  | "slots"
  | "live"
  | "sports"
  | "esports"
  | "fishing"
  | "arcade"
  | "lottery"
  | "other";

export type LaunchSession = {
  mode: "demo";
  kind: "original" | "unavailable";
  engineKey?: string;
  message: string;
  launchUrl?: string;
};

export type ProviderHealth = {
  status: "connected" | "demo" | "missing_credentials" | "error" | "disabled";
  healthStatus: "ok" | "degraded" | "down" | "unknown";
  message: string;
  credentialsConfigured: boolean;
};

export type WalletCallbackResult =
  | { accepted: false; reason: string }
  | { accepted: true; alreadyProcessed: boolean; message: string };

export interface GameProviderAdapter {
  key: string;
  getProviders(): Promise<{ code: string; name: string; category: ProviderCategory }[]>;
  syncGames(): Promise<{ synced: number; note: string }>;
  getGameDetails(slug: string): Promise<{ slug: string; available: boolean } | null>;
  createLaunchSession(input: {
    slug: string;
    userId: string;
    mode: "demo" | "live";
  }): Promise<LaunchSession>;
  verifyCallback(input: { payload: string; signature: string | null }): {
    ok: boolean;
    reason?: string;
  };
  processWalletTransaction(input: {
    payload: string;
    signature: string | null;
    idempotencyKey: string;
  }): Promise<WalletCallbackResult>;
  getProviderHealth(): Promise<ProviderHealth>;
}

function env(...keys: string[]) {
  return keys.every((key) => Boolean(process.env[key]?.trim()));
}

class NexoraOriginalAdapter implements GameProviderAdapter {
  key = "nexora-original";

  async getProviders() {
    return [{ code: "nexora", name: "Nexora Originals", category: "arcade" as const }];
  }

  async syncGames() {
    return { synced: 0, note: "Catalog is managed in-platform for original demo games." };
  }

  async getGameDetails(slug: string) {
    const [row] = await db.select().from(games).where(eq(games.slug, slug)).limit(1);
    if (!row) return null;
    return { slug: row.slug, available: row.status === "demo" || row.status === "available" };
  }

  async createLaunchSession(input: { slug: string; userId: string; mode: "demo" | "live" }) {
    if (input.mode === "live") {
      return {
        mode: "demo" as const,
        kind: "unavailable" as const,
        message:
          "Live provider sessions are disabled until licensing, jurisdictional approval, and provider authorization are confirmed.",
      };
    }
    const [row] = await db.select().from(games).where(eq(games.slug, input.slug)).limit(1);
    if (!row) {
      return { mode: "demo" as const, kind: "unavailable" as const, message: "Game was not found." };
    }
    if (row.launchKind !== "original" || !row.engineKey) {
      return {
        mode: "demo" as const,
        kind: "unavailable" as const,
        message: row.status === "maintenance" ? "This title is in maintenance." : "This title is not launchable yet.",
      };
    }
    return {
      mode: "demo" as const,
      kind: "original" as const,
      engineKey: row.engineKey,
      launchUrl: `/play/${row.slug}`,
      message: "Launching Nexora original demo game. Results are simulated.",
    };
  }

  verifyCallback() {
    return { ok: false, reason: "original_adapter_has_no_external_callbacks" };
  }

  async processWalletTransaction() {
    return { accepted: false as const, reason: "original_adapter_has_no_external_wallet" };
  }

  async getProviderHealth(): Promise<ProviderHealth> {
    return {
      status: "demo",
      healthStatus: "ok",
      credentialsConfigured: true,
      message: "Nexora original demo engines are online. No third-party credentials required.",
    };
  }
}

class ExternalStubAdapter implements GameProviderAdapter {
  constructor(
    public key: string,
    private name: string,
    private category: ProviderCategory,
    private requiredEnv: string[],
    private docs: string,
  ) {}

  async getProviders() {
    return [{ code: this.key, name: this.name, category: this.category }];
  }

  async syncGames() {
    const health = await this.getProviderHealth();
    if (!health.credentialsConfigured) {
      return { synced: 0, note: health.message };
    }
    return { synced: 0, note: "Credentials present, but commercial API access has not been authorized." };
  }

  async getGameDetails() {
    return null;
  }

  async createLaunchSession(): Promise<LaunchSession> {
    const health = await this.getProviderHealth();
    return {
      mode: "demo",
      kind: "unavailable",
      message: health.message,
    };
  }

  verifyCallback(input: { payload: string; signature: string | null }) {
    const secret = process.env[`${this.envPrefix()}_WEBHOOK_SECRET`] ?? "";
    return verifyWebhookSignature(secret, input.payload, input.signature);
  }

  async processWalletTransaction(input: {
    payload: string;
    signature: string | null;
    idempotencyKey: string;
  }): Promise<WalletCallbackResult> {
    const health = await this.getProviderHealth();
    if (!health.credentialsConfigured) {
      await recordCallback(this.key, input.idempotencyKey, input.payload, false, false, health.message);
      return { accepted: false, reason: health.message };
    }
    const verified = this.verifyCallback(input);
    if (!verified.ok) {
      await recordCallback(this.key, input.idempotencyKey, input.payload, false, false, verified.reason);
      return { accepted: false, reason: verified.reason ?? "invalid_signature" };
    }
    const existing = await db
      .select()
      .from(providerCallbacks)
      .where(
        and(
          eq(providerCallbacks.providerCode, this.key),
          eq(providerCallbacks.idempotencyKey, input.idempotencyKey),
        ),
      )
      .limit(1);
    if (existing[0]?.processed) {
      return { accepted: true, alreadyProcessed: true, message: "Idempotent replay ignored." };
    }
    await recordCallback(
      this.key,
      input.idempotencyKey,
      input.payload,
      true,
      false,
      "Signature valid, but real-money wallet callbacks stay disabled pending licensing.",
    );
    return {
      accepted: false,
      reason: "Real-money provider wallet callbacks are disabled until operator authorization is complete.",
    };
  }

  async getProviderHealth(): Promise<ProviderHealth> {
    const configured = env(...this.requiredEnv);
    if (!configured) {
      return {
        status: "missing_credentials",
        healthStatus: "unknown",
        credentialsConfigured: false,
        message: `${this.name} credentials are not configured. Required: ${this.requiredEnv.join(", ")}. ${this.docs}`,
      };
    }
    return {
      status: "connected",
      healthStatus: "degraded",
      credentialsConfigured: true,
      message: `${this.name} environment variables are present, but production launch remains disabled until commercial API access and licensing are confirmed.`,
    };
  }

  private envPrefix() {
    return this.key.replace(/-/g, "_").toUpperCase();
  }
}

async function recordCallback(
  providerCode: string,
  idempotencyKey: string,
  payload: string,
  signatureValid: boolean,
  processed: boolean,
  rejectionReason: string | null,
) {
  await db
    .insert(providerCallbacks)
    .values({
      providerCode,
      idempotencyKey,
      payloadHash: sha256(payload),
      signatureValid,
      processed,
      rejectionReason,
    })
    .onConflictDoNothing();
}

export const providerRegistry: Record<string, GameProviderAdapter> = {
  "nexora-original": new NexoraOriginalAdapter(),
  "pragmatic-play": new ExternalStubAdapter(
    "pragmatic-play",
    "Pragmatic Play",
    "slots",
    ["PRAGMATIC_API_URL", "PRAGMATIC_API_KEY", "PRAGMATIC_API_SECRET", "PRAGMATIC_WEBHOOK_SECRET"],
    "Request sandbox credentials from Pragmatic Play. Do not scrape or embed unauthorized game clients.",
  ),
  evolution: new ExternalStubAdapter(
    "evolution",
    "Evolution",
    "live",
    ["EVOLUTION_API_URL", "EVOLUTION_CASINO_KEY", "EVOLUTION_API_TOKEN", "EVOLUTION_WEBHOOK_SECRET"],
    "Request operator credentials from Evolution. Live dealer launch is blocked without a signed contract.",
  ),
  "sports-feed": new ExternalStubAdapter(
    "sports-feed",
    "Authorized Sports Feed",
    "sports",
    ["SPORTS_API_URL", "SPORTS_API_KEY"],
    "Connect a licensed sports data or sportsbook API. Fixture rows are labeled demo until then.",
  ),
  "esports-feed": new ExternalStubAdapter(
    "esports-feed",
    "Authorized Esports Feed",
    "esports",
    ["ESPORTS_API_URL", "ESPORTS_API_KEY"],
    "Connect a licensed esports data provider before displaying live series data.",
  ),
};

export function getAdapter(key: string) {
  return providerRegistry[key];
}

export async function refreshProviderHealth() {
  const rows = await db.select().from(gameProviders);
  const now = new Date();
  for (const row of rows) {
    const adapter = getAdapter(row.adapterKey);
    if (!adapter) continue;
    const health = await adapter.getProviderHealth();
    await db
      .update(gameProviders)
      .set({
        status: health.status,
        healthStatus: health.healthStatus,
        healthMessage: health.message,
        credentialsConfigured: health.credentialsConfigured,
        lastHealthCheck: now,
        updatedAt: now,
      })
      .where(eq(gameProviders.id, row.id));
  }
}

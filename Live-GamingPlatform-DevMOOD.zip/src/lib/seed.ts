import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  announcements,
  banners,
  gameCategories,
  gameProviders,
  games,
  promotions,
  promotionCodes,
  sportsEvents,
  sportsMarkets,
  systemSettings,
  users,
  vipTiers,
} from "@/db/schema";
import { createUserAccount } from "@/lib/auth";
import { refreshProviderHealth } from "@/lib/providers";

type GameSeed = {
  slug: string;
  name: string;
  category: string;
  provider: string;
  status: "demo" | "coming_soon" | "maintenance" | "restricted";
  hot?: boolean;
  rec?: boolean;
  isNew?: boolean;
  launchKind: "original" | "none";
  engineKey?: string;
  thumb?: string;
  hue: number;
  description: string;
};

const CATEGORIES = [
  { slug: "hot", name: "Hot Games", sortOrder: 1, icon: "flame", legalHold: false, legalNote: null },
  { slug: "slots", name: "Slots", sortOrder: 2, icon: "slots", legalHold: false, legalNote: null },
  { slug: "live", name: "Live Casino", sortOrder: 3, icon: "live", legalHold: false, legalNote: null },
  { slug: "sports", name: "Sports", sortOrder: 4, icon: "sports", legalHold: false, legalNote: null },
  { slug: "esports", name: "E-Sports", sortOrder: 5, icon: "esports", legalHold: false, legalNote: null },
  { slug: "fish", name: "Fish Games", sortOrder: 6, icon: "fish", legalHold: false, legalNote: null },
  { slug: "arcade", name: "Crash & Arcade", sortOrder: 7, icon: "arcade", legalHold: false, legalNote: null },
  { slug: "lottery", name: "Lottery", sortOrder: 8, icon: "lottery", legalHold: true, legalNote: "Lottery products remain disabled until jurisdictional approval." },
  { slug: "cockfight", name: "Cockfight", sortOrder: 9, icon: "hold", legalHold: true, legalNote: "This category is a placeholder and will not be offered unless legally approved." },
];

const PROVIDERS = [
  {
    code: "nexora",
    name: "Nexora Originals",
    category: "arcade",
    adapterKey: "nexora-original",
    status: "demo",
    configNote: "In-house HTML5 demo engines. No third-party key required.",
  },
  {
    code: "pragmatic-play",
    name: "Pragmatic Play",
    category: "slots",
    adapterKey: "pragmatic-play",
    status: "missing_credentials",
    configNote: "Requires PRAGMATIC_API_URL, PRAGMATIC_API_KEY, PRAGMATIC_API_SECRET, PRAGMATIC_WEBHOOK_SECRET.",
  },
  {
    code: "evolution",
    name: "Evolution",
    category: "live",
    adapterKey: "evolution",
    status: "missing_credentials",
    configNote: "Requires EVOLUTION_API_URL, EVOLUTION_CASINO_KEY, EVOLUTION_API_TOKEN, EVOLUTION_WEBHOOK_SECRET.",
  },
  {
    code: "sports-feed",
    name: "Authorized Sports Feed",
    category: "sports",
    adapterKey: "sports-feed",
    status: "missing_credentials",
    configNote: "Requires SPORTS_API_URL and SPORTS_API_KEY from a licensed sports data vendor.",
  },
  {
    code: "esports-feed",
    name: "Authorized Esports Feed",
    category: "esports",
    adapterKey: "esports-feed",
    status: "missing_credentials",
    configNote: "Requires ESPORTS_API_URL and ESPORTS_API_KEY.",
  },
];

const GAME_SEEDS: GameSeed[] = [
  { slug: "neon-reels", name: "Neon Reels", category: "slots", provider: "nexora", status: "demo", hot: true, rec: true, isNew: true, launchKind: "original", engineKey: "neon-reels", thumb: "/images/games/neon-reels.jpg", hue: 22, description: "Original three-reel demo slot. Server-settled outcomes. Simulated credits only." },
  { slug: "dragon-fortune", name: "Dragon Fortune", category: "slots", provider: "pragmatic-play", status: "coming_soon", hot: true, rec: true, launchKind: "none", thumb: "/images/games/dragon-fortune.jpg", hue: 18, description: "Catalog placeholder. Pragmatic Play studio launch requires authorized credentials." },
  { slug: "mystic-gems", name: "Mystic Gems", category: "slots", provider: "pragmatic-play", status: "coming_soon", rec: true, launchKind: "none", hue: 280, description: "Awaiting provider catalog sync." },
  { slug: "wild-safari", name: "Wild Safari", category: "slots", provider: "pragmatic-play", status: "coming_soon", launchKind: "none", hue: 92, description: "Awaiting provider catalog sync." },
  { slug: "lucky-lantern", name: "Lucky Lantern", category: "slots", provider: "pragmatic-play", status: "coming_soon", hot: true, launchKind: "none", hue: 8, description: "Awaiting provider catalog sync." },
  { slug: "crystal-burst", name: "Crystal Burst", category: "slots", provider: "pragmatic-play", status: "coming_soon", launchKind: "none", hue: 200, description: "Awaiting provider catalog sync." },
  { slug: "pharaoh-gold", name: "Pharaoh Gold", category: "slots", provider: "pragmatic-play", status: "coming_soon", rec: true, launchKind: "none", hue: 42, description: "Awaiting provider catalog sync." },
  { slug: "ocean-pearls", name: "Ocean Pearls", category: "slots", provider: "pragmatic-play", status: "coming_soon", launchKind: "none", hue: 188, description: "Awaiting provider catalog sync." },
  { slug: "thunder-reels", name: "Thunder Reels", category: "slots", provider: "pragmatic-play", status: "maintenance", launchKind: "none", hue: 230, description: "Marked maintenance in the catalog until the studio connection is authorized." },
  { slug: "candy-rush", name: "Candy Rush", category: "slots", provider: "pragmatic-play", status: "coming_soon", isNew: true, launchKind: "none", hue: 320, description: "Awaiting provider catalog sync." },
  { slug: "night-wolf", name: "Night Wolf", category: "slots", provider: "pragmatic-play", status: "coming_soon", hot: true, launchKind: "none", hue: 260, description: "Awaiting provider catalog sync." },
  { slug: "golden-koi", name: "Golden Koi", category: "slots", provider: "pragmatic-play", status: "coming_soon", launchKind: "none", hue: 36, description: "Awaiting provider catalog sync." },
  { slug: "nexora-roulette", name: "Studio Roulette", category: "live", provider: "evolution", status: "coming_soon", hot: true, rec: true, launchKind: "none", thumb: "/images/games/live-roulette.jpg", hue: 12, description: "Live dealer tables require an Evolution operator contract." },
  { slug: "speed-blackjack", name: "Speed Blackjack", category: "live", provider: "evolution", status: "coming_soon", rec: true, launchKind: "none", hue: 150, description: "Live dealer tables require authorized studio access." },
  { slug: "live-baccarat", name: "Live Baccarat", category: "live", provider: "evolution", status: "coming_soon", hot: true, launchKind: "none", hue: 0, description: "Live dealer tables require authorized studio access." },
  { slug: "dragon-tiger", name: "Dragon Tiger", category: "live", provider: "evolution", status: "coming_soon", launchKind: "none", hue: 14, description: "Live dealer tables require authorized studio access." },
  { slug: "lightning-dice", name: "Lightning Dice", category: "live", provider: "evolution", status: "coming_soon", launchKind: "none", hue: 48, description: "Live dealer tables require authorized studio access." },
  { slug: "studio-wheel", name: "Studio Wheel", category: "live", provider: "evolution", status: "maintenance", launchKind: "none", hue: 330, description: "Shown as maintenance until a live studio handshake exists." },
  { slug: "ocean-hunter", name: "Ocean Hunter", category: "fish", provider: "nexora", status: "coming_soon", hot: true, rec: true, launchKind: "none", thumb: "/images/games/ocean-hunter.jpg", hue: 196, description: "Fishing titles stay in catalog preview until an authorized arcade provider is connected." },
  { slug: "deep-treasure", name: "Deep Treasure", category: "fish", provider: "nexora", status: "coming_soon", launchKind: "none", hue: 210, description: "Catalog preview only." },
  { slug: "star-fish", name: "Star Fish", category: "fish", provider: "nexora", status: "coming_soon", isNew: true, launchKind: "none", hue: 172, description: "Catalog preview only." },
  { slug: "pulse-crash", name: "Pulse Crash", category: "arcade", provider: "nexora", status: "demo", hot: true, rec: true, isNew: true, launchKind: "original", engineKey: "pulse-crash", thumb: "/images/games/pulse-crash.jpg", hue: 16, description: "Original crash demo. Crash point is drawn on the server." },
  { slug: "lucky-dice", name: "Lucky Dice", category: "arcade", provider: "nexora", status: "demo", rec: true, launchKind: "original", engineKey: "lucky-dice", hue: 40, description: "Original dice demo with server-side settlement." },
  { slug: "tower-climb", name: "Tower Climb", category: "arcade", provider: "nexora", status: "coming_soon", launchKind: "none", hue: 268, description: "Arcade placeholder. Engine not shipped." },
  { slug: "grid-runner", name: "Grid Runner", category: "arcade", provider: "nexora", status: "coming_soon", launchKind: "none", hue: 300, description: "Arcade placeholder. Engine not shipped." },
];

const SETTINGS: Record<string, string> = {
  whatsapp_url: "",
  telegram_url: "",
  facebook_url: "",
  support_email: "",
  real_money_enabled: "false",
  min_age: "18",
  platform_name: "Nexora",
  demo_notice: "true",
};

export async function seedIfNeeded() {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) {
    await refreshProviderHealth();
    return { seeded: false };
  }

  for (const [key, value] of Object.entries(SETTINGS)) {
    await db.insert(systemSettings).values({ key, value }).onConflictDoNothing();
  }

  const categoryIds = new Map<string, string>();
  for (const cat of CATEGORIES) {
    const [row] = await db.insert(gameCategories).values(cat).returning();
    categoryIds.set(cat.slug, row.id);
  }

  const providerIds = new Map<string, string>();
  for (const provider of PROVIDERS) {
    const [row] = await db.insert(gameProviders).values(provider).returning();
    providerIds.set(provider.code, row.id);
  }

  let order = 0;
  for (const game of GAME_SEEDS) {
    const categoryId = categoryIds.get(game.category);
    const providerId = providerIds.get(game.provider);
    if (!categoryId || !providerId) continue;
    await db.insert(games).values({
      providerId,
      categoryId,
      slug: game.slug,
      name: game.name,
      thumbnailUrl: game.thumb ?? null,
      description: game.description,
      status: game.status,
      isHot: Boolean(game.hot),
      isNew: Boolean(game.isNew),
      isRecommended: Boolean(game.rec),
      launchKind: game.launchKind,
      engineKey: game.engineKey ?? null,
      sortOrder: order++,
      artHue: game.hue,
    });
  }

  await db.insert(banners).values([
    {
      title: "Welcome Boost 200%",
      subtitle: "Simulated demo credits on your first practice deposit. Not real money.",
      imageUrl: "/images/hero-welcome.jpg",
      href: "/account?tab=wallet",
      sortOrder: 1,
    },
    {
      title: "Live Studio Preview",
      subtitle: "Dealer tables stay locked until Evolution credentials and licensing are confirmed.",
      imageUrl: "/images/hero-live.jpg",
      href: "/games?category=live",
      sortOrder: 2,
    },
    {
      title: "Sports Fixtures",
      subtitle: "Sample matches for layout only. Odds are not live.",
      imageUrl: "/images/hero-sports.jpg",
      href: "/sports",
      sortOrder: 3,
    },
    {
      title: "Invite in demo",
      subtitle: "Share your referral code. Demo rewards never convert to cash.",
      imageUrl: "/images/promo-invite.jpg",
      href: "/promotions",
      sortOrder: 4,
    },
  ]);

  await db.insert(announcements).values([
    { message: "Nexora is running in demo mode. Balances are simulated NXC credits.", sortOrder: 1 },
    { message: "Provider studios show genuine connection status. Missing credentials are labeled, not faked.", sortOrder: 2 },
    { message: "Sports odds on this site are fixture samples with last-updated timestamps — not live betting markets.", sortOrder: 3 },
    { message: "Need help? Open a support ticket. External WhatsApp/Telegram buttons stay disabled until URLs are configured.", sortOrder: 4 },
  ]);

  const now = Date.now();
  const [welcome] = await db
    .insert(promotions)
    .values({
      slug: "welcome-demo",
      title: "Welcome Demo Boost",
      summary: "Claim 100 simulated NXC once per account.",
      body: "This promotion credits the demo wallet only. It is not a real-money bonus and cannot be withdrawn as cash.",
      kind: "welcome",
      imageUrl: "/images/hero-welcome.jpg",
      startsAt: new Date(now - 86400000),
      endsAt: new Date(now + 86400000 * 90),
      simulated: true,
      terms: "One redemption per user. Demo credits only. Server-side eligibility is enforced.",
      creditCents: 10000,
    })
    .returning();
  const [daily] = await db
    .insert(promotions)
    .values({
      slug: "daily-demo",
      title: "Daily Practice Pack",
      summary: "Use code NEXORA50 for 50 extra demo credits.",
      body: "Simulated daily pack. Code redemption is rate-limited per account.",
      kind: "daily",
      imageUrl: "/images/promo-invite.jpg",
      startsAt: new Date(now - 86400000),
      endsAt: new Date(now + 86400000 * 30),
      simulated: true,
      terms: "Demo only. Code NEXORA50. One use per player.",
      creditCents: 5000,
    })
    .returning();
  await db.insert(promotions).values([
    {
      slug: "cashback-demo",
      title: "Practice Cashback",
      summary: "VIP rebate preview based on simulated wager volume.",
      body: "Rebates are calculated from demo wagers and never settle to a real-money balance.",
      kind: "cashback",
      imageUrl: "/images/vip-lounge.jpg",
      startsAt: new Date(now - 86400000),
      endsAt: new Date(now + 86400000 * 60),
      simulated: true,
      terms: "Display only until a licensed wallet is authorized.",
      creditCents: 0,
    },
    {
      slug: "vip-path",
      title: "VIP Path",
      summary: "Bronze to Diamond based on demo wagers.",
      body: "Tier thresholds exist so the lobby can show progression. They do not unlock real-money benefits.",
      kind: "vip",
      imageUrl: "/images/vip-lounge.jpg",
      startsAt: new Date(now - 86400000),
      endsAt: new Date(now + 86400000 * 365),
      simulated: true,
      terms: "Simulated loyalty track.",
      creditCents: 0,
    },
  ]);
  await db.insert(promotionCodes).values([
    { promotionId: welcome.id, code: "WELCOME100", maxRedemptions: 100000, perUserLimit: 1 },
    { promotionId: daily.id, code: "NEXORA50", maxRedemptions: 100000, perUserLimit: 1 },
  ]);

  await db.insert(vipTiers).values([
    { name: "Bronze", minWagerCents: 0, rebateBps: 20, sortOrder: 1 },
    { name: "Silver", minWagerCents: 50000, rebateBps: 35, sortOrder: 2 },
    { name: "Gold", minWagerCents: 200000, rebateBps: 50, sortOrder: 3 },
    { name: "Platinum", minWagerCents: 800000, rebateBps: 70, sortOrder: 4 },
    { name: "Diamond", minWagerCents: 2500000, rebateBps: 100, sortOrder: 5 },
  ]);

  const kickoff = new Date(now + 3600_000);
  const liveAt = new Date(now - 1200_000);
  const [football] = await db
    .insert(sportsEvents)
    .values({
      sport: "Football",
      league: "Demo Premier",
      homeTeam: "North Forge",
      awayTeam: "Harbor United",
      startAt: liveAt,
      status: "live",
      homeScore: 1,
      awayScore: 0,
      isLive: true,
      suspended: false,
      dataSource: "fixture",
      lastUpdatedAt: new Date(),
    })
    .returning();
  const [basket] = await db
    .insert(sportsEvents)
    .values({
      sport: "Basketball",
      league: "Demo Cup",
      homeTeam: "Metro Lions",
      awayTeam: "Coastal Bears",
      startAt: kickoff,
      status: "upcoming",
      isLive: false,
      dataSource: "fixture",
      lastUpdatedAt: new Date(),
    })
    .returning();
  const [cs] = await db
    .insert(sportsEvents)
    .values({
      sport: "Esports",
      league: "Nexora Invitational (fixture)",
      homeTeam: "Orbit Five",
      awayTeam: "Volt Clan",
      startAt: new Date(now + 7200_000),
      status: "upcoming",
      isLive: false,
      dataSource: "fixture",
      lastUpdatedAt: new Date(),
    })
    .returning();
  const [suspended] = await db
    .insert(sportsEvents)
    .values({
      sport: "Football",
      league: "Demo Premier",
      homeTeam: "River FC",
      awayTeam: "Summit AFC",
      startAt: liveAt,
      status: "live",
      homeScore: 0,
      awayScore: 0,
      isLive: true,
      suspended: true,
      dataSource: "fixture",
      lastUpdatedAt: new Date(),
    })
    .returning();

  const fixtureNote = { name: "1", odds: "1.90", suspended: false };
  await db.insert(sportsMarkets).values([
    {
      eventId: football.id,
      name: "Match result (fixture sample)",
      status: "open",
      selections: [
        { name: "North Forge", odds: "1.85", suspended: false },
        { name: "Draw", odds: "3.40", suspended: false },
        { name: "Harbor United", odds: "4.20", suspended: false },
      ],
      lastUpdatedAt: new Date(),
    },
    {
      eventId: basket.id,
      name: "Winner (fixture sample)",
      status: "open",
      selections: [
        { name: "Metro Lions", odds: "1.70", suspended: false },
        { name: "Coastal Bears", odds: "2.15", suspended: false },
      ],
      lastUpdatedAt: new Date(),
    },
    {
      eventId: cs.id,
      name: "Map 1 winner (fixture sample)",
      status: "open",
      selections: [
        { name: "Orbit Five", odds: "1.65", suspended: false },
        { name: "Volt Clan", odds: "2.20", suspended: false },
      ],
      lastUpdatedAt: new Date(),
    },
    {
      eventId: suspended.id,
      name: "Match result",
      status: "suspended",
      selections: [
        { ...fixtureNote, name: "River FC", suspended: true },
        { name: "Draw", odds: "3.10", suspended: true },
        { name: "Summit AFC", odds: "3.80", suspended: true },
      ],
      lastUpdatedAt: new Date(),
    },
  ]);

  const player = await createUserAccount({
    email: "player@nexora.play",
    password: "Demo1234!",
    displayName: "Demo Player",
    dateOfBirth: "1994-04-12",
    country: "US",
    language: "en",
  });
  await db.update(users).set({ ageVerified: true, emailVerified: true }).where(eq(users.id, player.id));

  const admin = await createUserAccount({
    email: "admin@nexora.play",
    password: "Admin1234!",
    displayName: "Nexora Admin",
    dateOfBirth: "1988-01-20",
    country: "US",
    language: "en",
  });
  await db
    .update(users)
    .set({ role: "super_admin", ageVerified: true, emailVerified: true })
    .where(eq(users.id, admin.id));

  const support = await createUserAccount({
    email: "support@nexora.play",
    password: "Support1234!",
    displayName: "Support Desk",
    dateOfBirth: "1990-06-02",
    country: "US",
  });
  await db.update(users).set({ role: "support", ageVerified: true }).where(eq(users.id, support.id));

  await refreshProviderHealth();
  return { seeded: true };
}

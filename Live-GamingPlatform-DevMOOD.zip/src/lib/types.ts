export type PublicUser = {
  id: string;
  email: string;
  displayName: string;
  role: string;
  status: string;
  language: string;
  ageVerified: boolean;
  jurisdictionEligible: boolean;
  referralCode: string;
  country: string | null;
  dateOfBirth: string | null;
  selfExcludedUntil: string | null;
  coolingOffUntil: string | null;
  mfaEnabled: boolean;
};

export type ProviderInfo = {
  id: string;
  code: string;
  name: string;
  category: string;
  status: string;
  healthStatus: string;
  healthMessage: string | null;
  credentialsConfigured: boolean;
  lastHealthCheck: string | null;
};

export type CategoryInfo = {
  id: string;
  slug: string;
  name: string;
  sortOrder: number;
  enabled: boolean;
  legalHold: boolean;
  legalNote: string | null;
  icon: string;
};

export type GameItem = {
  id: string;
  slug: string;
  name: string;
  thumbnailUrl: string | null;
  description: string | null;
  status: string;
  isHot: boolean;
  isNew: boolean;
  isRecommended: boolean;
  launchKind: string;
  engineKey: string | null;
  playCount: number;
  artHue: number;
  favorited?: boolean;
  provider?: { code: string; name: string; status: string } | null;
  category?: { slug: string; name: string; legalHold: boolean } | null;
};

export type BannerItem = {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  href: string;
};

export type Bootstrap = {
  user: PublicUser | null;
  demoBalance: number;
  demoBalanceLabel: string;
  banners: BannerItem[];
  announcements: string[];
  categories: CategoryInfo[];
  providers: ProviderInfo[];
  social: { whatsapp: string; telegram: string; facebook: string; supportEmail: string };
  realMoneyEnabled: boolean;
  platform: { name: string; demo: boolean };
};

import { randomInt } from "crypto";

export type EngineResult = {
  outcome: Record<string, unknown>;
  payoutCents: number;
  multiplier: number;
};

const SLOT_SYMBOLS = ["orange", "gold", "seven", "star", "cherry", "bar"] as const;

export function playEngine(engineKey: string, betCents: number, extra?: Record<string, unknown>): EngineResult {
  if (betCents < 50 || betCents > 50000) {
    throw new Error("Demo bet must be between 0.50 and 500.00 NXC.");
  }
  if (engineKey === "neon-reels") return playSlots(betCents);
  if (engineKey === "pulse-crash") return playCrash(betCents, extra);
  if (engineKey === "lucky-dice") return playDice(betCents, extra);
  throw new Error("This original demo engine is not available.");
}

function playSlots(betCents: number): EngineResult {
  const reels = [pick(), pick(), pick()];
  let multiplier = 0;
  if (reels[0] === reels[1] && reels[1] === reels[2]) {
    multiplier = reels[0] === "seven" ? 12 : reels[0] === "gold" ? 8 : 5;
  } else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) {
    multiplier = 1;
  }
  return {
    outcome: { reels },
    multiplier,
    payoutCents: Math.floor(betCents * multiplier),
  };
}

function playCrash(betCents: number, extra?: Record<string, unknown>): EngineResult {
  const crashAt = crashPoint();
  const requested = Number(extra?.cashoutAt ?? 0);
  const cashed = requested >= 1.01 && requested <= crashAt;
  const multiplier = cashed ? Math.round(requested * 100) / 100 : 0;
  return {
    outcome: { crashAt, cashedOut: cashed, cashoutAt: requested || null },
    multiplier,
    payoutCents: cashed ? Math.floor(betCents * multiplier) : 0,
  };
}

function playDice(betCents: number, extra?: Record<string, unknown>): EngineResult {
  const guess = String(extra?.guess ?? "high");
  const roll = randomInt(1, 7);
  const win = guess === "high" ? roll >= 4 : guess === "low" ? roll <= 3 : false;
  const multiplier = win ? 1.9 : 0;
  return {
    outcome: { roll, guess },
    multiplier,
    payoutCents: win ? Math.floor(betCents * multiplier) : 0,
  };
}

function pick() {
  return SLOT_SYMBOLS[randomInt(0, SLOT_SYMBOLS.length)];
}

function crashPoint() {
  const n = randomInt(1, 10001) / 10000;
  const raw = 0.96 / (1 - n);
  return Math.max(1.0, Math.min(100, Math.floor(raw * 100) / 100));
}

export const ENGINE_RULES: Record<string, string> = {
  "neon-reels": "Three-reel demo slot. Triple match pays 5x–12x. Pair pays 1x. Outcomes are generated on the server.",
  "pulse-crash": "Server draws a crash point. Cash out before it to receive the multiplier. Miss it and the demo stake is lost.",
  "lucky-dice": "Guess high (4-6) or low (1-3). A win returns 1.9x the demo stake. House edge is visible and simulated.",
};

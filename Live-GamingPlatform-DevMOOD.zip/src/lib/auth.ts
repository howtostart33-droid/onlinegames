import { cookies } from "next/headers";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  gameFavorites,
  ledgerAccounts,
  notifications,
  responsibleGamingLimits,
  userSessions,
  users,
  wallets,
} from "@/db/schema";
import { hashPassword, randomToken, sha256, verifyPassword } from "@/lib/crypto";

export const SESSION_COOKIE = "nexora_session";
const SESSION_DAYS = 7;
export const STAFF_ROLES = ["super_admin", "operations", "support", "finance", "analyst"] as const;
export type StaffRole = (typeof STAFF_ROLES)[number];

export type PublicUser = {
  id: string;
  email: string;
  displayName: string;
  role: string;
  status: string;
  language: string;
  ageVerified: boolean;
  jurisdictionEligible: boolean;
  referralCode: string;
  country: string | null;
  dateOfBirth: string | null;
  selfExcludedUntil: string | null;
  coolingOffUntil: string | null;
  mfaEnabled: boolean;
};

export function toPublicUser(row: typeof users.$inferSelect): PublicUser {
  return {
    id: row.id,
    email: row.email,
    displayName: row.displayName,
    role: row.role,
    status: row.status,
    language: row.language,
    ageVerified: row.ageVerified,
    jurisdictionEligible: row.jurisdictionEligible,
    referralCode: row.referralCode,
    country: row.country,
    dateOfBirth: row.dateOfBirth,
    selfExcludedUntil: row.selfExcludedUntil ? row.selfExcludedUntil.toISOString() : null,
    coolingOffUntil: row.coolingOffUntil ? row.coolingOffUntil.toISOString() : null,
    mfaEnabled: row.mfaEnabled,
  };
}

export function isStaff(role: string) {
  return STAFF_ROLES.includes(role as StaffRole);
}

export function canAccessAdmin(role: string) {
  return isStaff(role);
}

export function roleAllows(role: string, action: "read" | "users" | "finance" | "catalog" | "support" | "system") {
  if (role === "super_admin") return true;
  if (role === "analyst") return action === "read";
  if (role === "support") return action === "read" || action === "support" || action === "users";
  if (role === "finance") return action === "read" || action === "finance";
  if (role === "operations") return action !== "system";
  return false;
}

function referralCode() {
  return `NX${randomToken(4).slice(0, 8).toUpperCase()}`;
}

export async function createUserAccount(input: {
  email: string;
  password: string;
  displayName: string;
  phone?: string;
  dateOfBirth?: string;
  country?: string;
  language?: string;
  referredByCode?: string;
}) {
  const email = input.email.trim().toLowerCase();
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing[0]) throw new Error("An account with that email already exists.");

  let referredBy: string | undefined;
  if (input.referredByCode) {
    const [ref] = await db.select().from(users).where(eq(users.referralCode, input.referredByCode.trim().toUpperCase())).limit(1);
    referredBy = ref?.id;
  }

  const ageVerified = isAtLeast18(input.dateOfBirth);
  const passwordHash = await hashPassword(input.password);
  const [user] = await db
    .insert(users)
    .values({
      email,
      phone: input.phone || null,
      passwordHash,
      displayName: input.displayName.trim(),
      language: input.language === "bn" ? "bn" : "en",
      dateOfBirth: input.dateOfBirth || null,
      country: input.country || null,
      ageVerified,
      jurisdictionEligible: false,
      referralCode: referralCode(),
      referredBy,
    })
    .returning();

  await provisionWallets(user.id);
  await db.insert(responsibleGamingLimits).values({ userId: user.id });
  await db.insert(notifications).values({
    userId: user.id,
    title: "Welcome to Nexora demo",
    body: "You are in simulated mode. Real-money wagering is disabled pending operator licensing.",
  });
  await writeAudit(user.id, "auth.register", "user", user.id);
  return user;
}

export async function provisionWallets(userId: string) {
  const [demo] = await db
    .insert(wallets)
    .values({
      userId,
      type: "demo",
      currency: "NXC",
      availableCents: 1000000,
      status: "active",
    })
    .returning();
  const [real] = await db
    .insert(wallets)
    .values({
      userId,
      type: "real",
      currency: "USD",
      availableCents: 0,
      status: "locked",
    })
    .returning();
  await db.insert(ledgerAccounts).values([
    { walletId: demo.id, userId, code: "cash", kind: "asset" },
    { walletId: demo.id, userId, code: "clearing", kind: "liability" },
    { walletId: real.id, userId, code: "cash", kind: "asset" },
    { walletId: real.id, userId, code: "clearing", kind: "liability" },
  ]);
}

export function isAtLeast18(dateOfBirth?: string | null) {
  if (!dateOfBirth) return false;
  const dob = new Date(dateOfBirth);
  if (Number.isNaN(dob.getTime())) return false;
  const cutoff = new Date();
  cutoff.setFullYear(cutoff.getFullYear() - 18);
  return dob <= cutoff;
}

export async function authenticate(email: string, password: string, meta: { ip?: string; userAgent?: string }) {
  const [user] = await db.select().from(users).where(eq(users.email, email.trim().toLowerCase())).limit(1);
  if (!user) throw new Error("Invalid email or password.");
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    throw new Error("Account is temporarily locked after repeated failed logins.");
  }
  if (user.status === "closed") throw new Error("This account is closed.");
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    const attempts = user.failedLoginAttempts + 1;
    const lockedUntil = attempts >= 8 ? new Date(Date.now() + 15 * 60 * 1000) : null;
    await db
      .update(users)
      .set({ failedLoginAttempts: attempts, lockedUntil, updatedAt: new Date() })
      .where(eq(users.id, user.id));
    throw new Error("Invalid email or password.");
  }
  if (user.selfExcludedUntil && user.selfExcludedUntil > new Date()) {
    throw new Error("This account is self-excluded. Responsible gaming controls are in effect.");
  }
  await db
    .update(users)
    .set({ failedLoginAttempts: 0, lockedUntil: null, lastLoginAt: new Date(), updatedAt: new Date() })
    .where(eq(users.id, user.id));
  const raw = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(userSessions).values({
    userId: user.id,
    tokenHash: sha256(raw),
    userAgent: meta.userAgent ?? null,
    ip: meta.ip ?? null,
    expiresAt,
  });
  await writeAudit(user.id, "auth.login", "user", user.id, { ip: meta.ip });
  return { user, token: raw, expiresAt };
}

export async function setSessionCookie(token: string, expiresAt: Date) {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
    secure: process.env.NODE_ENV === "production",
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", expires: new Date(0) });
}

export async function getSessionUser() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [session] = await db
    .select()
    .from(userSessions)
    .where(and(eq(userSessions.tokenHash, sha256(token)), isNull(userSessions.revokedAt)))
    .limit(1);
  if (!session || session.expiresAt < new Date()) return null;
  const [user] = await db.select().from(users).where(eq(users.id, session.userId)).limit(1);
  if (!user || user.status === "closed") return null;
  return { user, session };
}

export async function revokeCurrentSession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return;
  await db
    .update(userSessions)
    .set({ revokedAt: new Date() })
    .where(eq(userSessions.tokenHash, sha256(token)));
  await clearSessionCookie();
}

export async function writeAudit(
  actorId: string | null,
  action: string,
  entity: string,
  entityId?: string | null,
  meta?: Record<string, unknown>,
  ip?: string,
) {
  await db.insert(auditLogs).values({
    actorId,
    action,
    entity,
    entityId: entityId ?? null,
    meta: meta ?? {},
    ip: ip ?? null,
  });
}

export async function favoriteIdsFor(userId: string) {
  const rows = await db.select({ gameId: gameFavorites.gameId }).from(gameFavorites).where(eq(gameFavorites.userId, userId));
  return new Set(rows.map((row) => row.gameId));
}

const buckets = new Map<string, { count: number; reset: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const current = buckets.get(key);
  if (!current || current.reset < now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, remaining: limit - 1 };
  }
  if (current.count >= limit) return { ok: false, remaining: 0 };
  current.count += 1;
  return { ok: true, remaining: limit - current.count };
}

export function clientIp(req: Request) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "127.0.0.1";
}

export function jsonError(message: string, status = 400, extra?: Record<string, unknown>) {
  return Response.json({ ok: false, error: message, ...extra }, { status });
}

export function jsonOk(data: unknown, status = 200) {
  return Response.json({ ok: true, data }, { status });
}

import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  depositRequests,
  ledgerAccounts,
  ledgerEntries,
  ledgerTransactions,
  wallets,
  withdrawalRequests,
} from "@/db/schema";

export const DEMO_CURRENCY = "NXC";
export const REAL_MONEY_DISABLED_REASON =
  "Real-money deposits, withdrawals, and wagering stay disabled until licensing, jurisdictional legality, provider authorization, payment-provider approval, age verification, and compliance controls are confirmed.";

export async function getDemoWallet(userId: string) {
  const [wallet] = await db
    .select()
    .from(wallets)
    .where(and(eq(wallets.userId, userId), eq(wallets.type, "demo")))
    .limit(1);
  return wallet ?? null;
}

export async function postLedger(input: {
  userId: string;
  walletType: "demo" | "real";
  type: string;
  amountCents: number;
  idempotencyKey: string;
  reason: string;
  actorId?: string;
  reference?: string;
  meta?: Record<string, unknown>;
}) {
  if (input.amountCents <= 0) {
    throw new Error("Amount must be positive");
  }
  if (input.walletType === "real") {
    throw new Error(REAL_MONEY_DISABLED_REASON);
  }

  return db.transaction(async (tx) => {
    const existing = await tx
      .select()
      .from(ledgerTransactions)
      .where(eq(ledgerTransactions.idempotencyKey, input.idempotencyKey))
      .limit(1);
    if (existing[0]) {
      return { transaction: existing[0], duplicate: true as const };
    }

    const lockedRows = await tx
      .select()
      .from(wallets)
      .where(and(eq(wallets.userId, input.userId), eq(wallets.type, input.walletType)))
      .for("update")
      .limit(1);
    const locked = lockedRows[0];

    if (!locked) throw new Error("Wallet not found");
    if (locked.status !== "active") throw new Error("Wallet is not active");

    const debitTypes = new Set(["withdrawal", "wager", "adjustment_debit"]);
    const isDebit = debitTypes.has(input.type);
    if (isDebit && locked.availableCents < input.amountCents) {
      throw new Error("Insufficient demo balance");
    }

    const next = isDebit
      ? locked.availableCents - input.amountCents
      : locked.availableCents + input.amountCents;

    await tx
      .update(wallets)
      .set({
        availableCents: next,
        version: locked.version + 1,
        updatedAt: new Date(),
      })
      .where(eq(wallets.id, locked.id));

    const [cash] = await tx
      .select()
      .from(ledgerAccounts)
      .where(and(eq(ledgerAccounts.walletId, locked.id), eq(ledgerAccounts.code, "cash")))
      .limit(1);
    const [clearing] = await tx
      .select()
      .from(ledgerAccounts)
      .where(and(eq(ledgerAccounts.walletId, locked.id), eq(ledgerAccounts.code, "clearing")))
      .limit(1);
    if (!cash || !clearing) throw new Error("Ledger accounts missing");

    const [transaction] = await tx
      .insert(ledgerTransactions)
      .values({
        walletId: locked.id,
        userId: input.userId,
        type: input.type,
        amountCents: input.amountCents,
        status: "completed",
        idempotencyKey: input.idempotencyKey,
        reference: input.reference,
        actorId: input.actorId,
        reason: input.reason,
        meta: input.meta ?? {},
      })
      .returning();

    await tx.insert(ledgerEntries).values([
      {
        transactionId: transaction.id,
        accountId: isDebit ? cash.id : clearing.id,
        direction: "debit",
        amountCents: input.amountCents,
      },
      {
        transactionId: transaction.id,
        accountId: isDebit ? clearing.id : cash.id,
        direction: "credit",
        amountCents: input.amountCents,
      },
    ]);

    return { transaction, duplicate: false as const, balanceCents: next };
  });
}

export async function listTransactions(userId: string, limit = 30) {
  return db
    .select()
    .from(ledgerTransactions)
    .where(eq(ledgerTransactions.userId, userId))
    .orderBy(desc(ledgerTransactions.createdAt))
    .limit(limit);
}

export async function createDemoDeposit(userId: string, amountCents: number, idempotencyKey: string) {
  const wallet = await getDemoWallet(userId);
  if (!wallet) throw new Error("Demo wallet missing");
  const posted = await postLedger({
    userId,
    walletType: "demo",
    type: "deposit",
    amountCents,
    idempotencyKey,
    reason: "Simulated demo deposit. No payment was collected.",
  });
  if (!posted.duplicate) {
    await db.insert(depositRequests).values({
      userId,
      walletId: wallet.id,
      amountCents,
      status: "completed",
      mode: "demo",
      reviewNote: "Simulated. Payment provider was not contacted.",
    });
  }
  return posted;
}

export async function createDemoWithdrawal(userId: string, amountCents: number, idempotencyKey: string) {
  const wallet = await getDemoWallet(userId);
  if (!wallet) throw new Error("Demo wallet missing");
  const posted = await postLedger({
    userId,
    walletType: "demo",
    type: "withdrawal",
    amountCents,
    idempotencyKey,
    reason: "Simulated demo withdrawal. No funds were transferred.",
  });
  if (!posted.duplicate) {
    await db.insert(withdrawalRequests).values({
      userId,
      walletId: wallet.id,
      amountCents,
      status: "completed",
      mode: "demo",
      reviewNote: "Simulated. Payment provider was not contacted.",
    });
  }
  return posted;
}

export function formatCredits(cents: number) {
  return (cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

import { AccountPage } from "@/components/pages";

export default function Page() {
  return <AccountPage />;
}

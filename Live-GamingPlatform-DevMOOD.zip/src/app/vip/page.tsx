import { VipPage } from "@/components/pages";

export default function Page() {
  return <VipPage />;
}

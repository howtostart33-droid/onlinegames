import { Lobby } from "@/components/lobby";
import { getBootstrap } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const bootstrap = await getBootstrap();
  return <Lobby bootstrap={bootstrap} />;
}

export default function DownloadPage() {
  return (
    <div className="nx-card p-6">
      <h1 className="font-display text-3xl font-bold">App download</h1>
      <p className="mt-3 max-w-2xl text-sm text-[#9a9aa8]">
        Native iOS and Android packages are not published yet. This page is the official placeholder so the navigation item works. When a signed store listing exists, the operator can add the store URLs in system settings.
      </p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-[#2a2c34] p-4">
          <p className="font-semibold">iOS</p>
          <p className="text-sm text-[#9a9aa8]">App Store listing not configured.</p>
        </div>
        <div className="rounded-xl border border-[#2a2c34] p-4">
          <p className="font-semibold">Android</p>
          <p className="text-sm text-[#9a9aa8]">Play Store listing not configured.</p>
        </div>
      </div>
    </div>
  );
}

import { Catalog } from "@/components/lobby";

export default async function GamesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string; filter?: string }>;
}) {
  const sp = await searchParams;
  return <Catalog initialQ={sp.q} initialCategory={sp.category} initialFilter={sp.filter} />;
}

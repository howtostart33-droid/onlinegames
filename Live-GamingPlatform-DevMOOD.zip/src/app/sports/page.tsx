import { SportsBoard } from "@/components/pages";

export default async function SportsPage({ searchParams }: { searchParams: Promise<{ sport?: string }> }) {
  const sp = await searchParams;
  return <SportsBoard sport={sp.sport} />;
}

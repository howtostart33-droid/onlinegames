import { SportsEvent } from "@/components/pages";

export default async function EventPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <SportsEvent id={id} />;
}

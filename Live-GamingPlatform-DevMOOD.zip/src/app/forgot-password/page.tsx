"use client";

import { useState } from "react";
import { AuthForm } from "@/components/lobby";

export default function ForgotPage() {
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <div className="space-y-6">
      <AuthForm mode="forgot" />
      <form
        className="nx-card mx-auto w-full max-w-md p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          const res = await fetch("/api/v1/auth/reset-password", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ token, password }),
          });
          const j = await res.json();
          setMsg(j.ok ? "Password updated. You can log in." : j.error);
        }}
      >
        <h2 className="font-display text-2xl font-bold">Use reset token</h2>
        <input className="nx-input mt-3" value={token} onChange={(e) => setToken(e.target.value)} placeholder="Token" />
        <input className="nx-input mt-3" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="New password" />
        <button className="nx-btn mt-4 w-full">Reset password</button>
        {msg ? <p className="mt-2 text-sm text-[#ffb03a]">{msg}</p> : null}
      </form>
    </div>
  );
}

export const dynamic = "force-dynamic";
export { GET, POST, PATCH, DELETE } from "@/server/v1";

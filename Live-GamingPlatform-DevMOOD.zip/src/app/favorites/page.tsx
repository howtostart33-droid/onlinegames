import { FavoritesPage } from "@/components/pages";

export default function Page() {
  return <FavoritesPage />;
}

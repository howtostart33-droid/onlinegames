import { AuthForm } from "@/components/lobby";

export default function LoginPage() {
  return <AuthForm mode="login" />;
}

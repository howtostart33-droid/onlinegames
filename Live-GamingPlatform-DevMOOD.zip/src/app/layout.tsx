import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Rajdhani, Be_Vietnam_Pro } from "next/font/google";
import { AppShell } from "@/components/shell";
import { getBootstrap } from "@/lib/data";
import "./globals.css";

const display = Rajdhani({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-display",
});

const body = Be_Vietnam_Pro({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
});

export const metadata: Metadata = {
  title: "Nexora | Demo gaming lobby",
  description:
    "Nexora is a demo-mode entertainment platform. Real-money wagering stays disabled pending licensing and provider authorization.",
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  const bootstrap = await getBootstrap();
  return (
    <html lang="en">
      <body className={`${display.variable} ${body.variable} bg-[#070708] text-white antialiased`}>
        <AppShell initial={bootstrap}>{children}</AppShell>
      </body>
    </html>
  );
}

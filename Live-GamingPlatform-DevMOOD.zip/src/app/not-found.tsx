import Link from "next/link";

export default function NotFound() {
  return (
    <div className="nx-card mx-auto max-w-lg p-8 text-center">
      <h1 className="font-display text-3xl font-bold">Page not found</h1>
      <p className="mt-3 text-sm text-[#9a9aa8]">That route is not part of the Nexora lobby.</p>
      <Link href="/" className="nx-btn mt-5 inline-flex">
        Back home
      </Link>
    </div>
  );
}

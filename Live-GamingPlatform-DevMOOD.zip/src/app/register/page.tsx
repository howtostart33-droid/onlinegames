import { AuthForm } from "@/components/lobby";

export default function RegisterPage() {
  return <AuthForm mode="register" />;
}

import { notFound } from "next/navigation";

const PAGES: Record<string, { title: string; body: string[] }> = {
  about: {
    title: "About Us",
    body: [
      "Nexora is an original entertainment lobby inspired by common gaming-site layouts. It is not affiliated with gk222.io and does not copy proprietary artwork, logos, or source code.",
      "The product currently runs in demo mode with simulated NXC credits, original HTML5 practice games, and a provider adapter layer that reports genuine credential status.",
      "Real-money wagering, deposits, withdrawals, and live gambling remain disabled until the operator confirms licensing, jurisdictional legality, provider authorization, payment-provider approval, age verification, and required compliance controls.",
    ],
  },
  contact: {
    title: "Contact Us",
    body: [
      "Use the in-app support ticket form for account help. External WhatsApp, Telegram, and Facebook buttons stay inactive until authorized URLs are saved in system settings.",
      "Do not treat unconfigured social buttons as official operator contacts.",
    ],
  },
  terms: {
    title: "Terms and Conditions",
    body: [
      "Nexora is provided as a demonstration platform. Demo credits have no cash value and cannot be withdrawn as money.",
      "You must be 18 or older. Age verification is required before launching practice games.",
      "You may not attempt to reverse-engineer provider integrations, manipulate client-side balances, or replay financial callbacks.",
      "We may suspend accounts that abuse rate limits, submit fraudulent support claims, or attempt to bypass role checks.",
    ],
  },
  privacy: {
    title: "Privacy Policy",
    body: [
      "We store account email, optional phone, hashed passwords, session metadata, and demo ledger activity.",
      "Passwords, payment secrets, and provider credentials are never stored in plaintext. Provider secrets belong in server environment variables.",
      "Data retention: closed accounts can be marked closed; ledger rows are kept for audit integrity.",
      "This demo does not sell personal information.",
    ],
  },
  responsible: {
    title: "Responsible Gaming",
    body: [
      "Even in demo mode, Nexora includes age checks, cooling-off, self-exclusion, deposit caps, and account closure.",
      "If you feel that gambling-style play is becoming a problem, stop and seek local support resources.",
      "Real-money features will not be switched on from the admin panel until legal authorization is documented.",
    ],
  },
};

export default async function LegalPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = PAGES[slug];
  if (!page) notFound();
  return (
    <article className="nx-card max-w-3xl p-6">
      <h1 className="font-display text-3xl font-bold">{page.title}</h1>
      {page.body.map((p) => (
        <p key={p} className="mt-4 text-sm leading-7 text-[#c8c8d2]">
          {p}
        </p>
      ))}
    </article>
  );
}

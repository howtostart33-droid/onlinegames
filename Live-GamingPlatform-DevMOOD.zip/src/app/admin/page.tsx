import { AdminPage } from "@/components/pages";
import { getSessionUser, canAccessAdmin } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function Page() {
  const session = await getSessionUser();
  if (!session || !canAccessAdmin(session.user.role)) {
    redirect("/login");
  }
  return <AdminPage />;
}

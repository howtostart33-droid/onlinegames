import { PlayTable } from "@/components/play";

export default async function PlayPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <PlayTable slug={slug} />;
}

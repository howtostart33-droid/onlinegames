"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { Icons } from "@/components/icons";
import type { Bootstrap } from "@/lib/types";
import { copy, type Lang } from "@/lib/i18n";

const NAV = [
  { href: "/", key: "home", icon: Icons.home },
  { href: "/favorites", key: "favorites", icon: Icons.star },
  { href: "/vip", key: "vip", icon: Icons.crown },
  { href: "/account?tab=rebates", key: "rebates", icon: Icons.trophy },
  { href: "/account?tab=rewards", key: "rewards", icon: Icons.gift },
  { href: "/promotions", key: "promotion", icon: Icons.megaphone },
  { href: "/account?tab=wallet", key: "deposit", icon: Icons.wallet },
  { href: "/account?tab=wallet&action=withdraw", key: "withdrawal", icon: Icons.withdraw },
  { href: "/support", key: "help", icon: Icons.help },
  { href: "/download", key: "download", icon: Icons.download },
  { href: "/support", key: "support", icon: Icons.headset },
] as const;

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2">
      <span className="nx-gradient grid h-9 w-9 place-items-center rounded-lg font-display text-lg font-black text-black">N</span>
      {compact ? null : (
        <span className="font-display text-xl font-black tracking-[0.14em]">
          NEXORA<span className="text-[#ff7a00]">.</span>
        </span>
      )}
    </Link>
  );
}

export function AppShell({ children, initial }: { children: React.ReactNode; initial?: Bootstrap | null }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<Bootstrap | null>(initial ?? null);
  const [lang, setLang] = useState<Lang>((initial?.user?.language as Lang) || "en");
  const [showTop, setShowTop] = useState(false);
  const [codeOpen, setCodeOpen] = useState(false);
  const [code, setCode] = useState("");
  const [codeMsg, setCodeMsg] = useState("");
  const t = copy[lang];

  useEffect(() => {
    if (initial) return;
    fetch("/api/v1/bootstrap")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) {
          setData(j.data);
          if (j.data.user?.language) setLang(j.data.user.language);
        }
      })
      .catch(() => undefined);
  }, [initial]);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  const social = data?.social;
  const staff = data?.user && ["super_admin", "operations", "support", "finance", "analyst"].includes(data.user.role);

  async function logout() {
    await fetch("/api/v1/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
    const res = await fetch("/api/v1/bootstrap");
    const j = await res.json();
    if (j.ok) setData(j.data);
  }

  async function switchLang(next: Lang) {
    setLang(next);
    document.cookie = `nexora_lang=${next}; path=/; max-age=31536000`;
    if (data?.user) {
      await fetch("/api/v1/me/language", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ language: next }),
      });
    }
  }

  async function redeem() {
    setCodeMsg("");
    const res = await fetch("/api/v1/promotions/redeem", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code }),
    });
    const j = await res.json();
    setCodeMsg(j.ok ? "Simulated credits applied." : j.error || "Unable to redeem.");
    if (j.ok) {
      const boot = await fetch("/api/v1/bootstrap").then((r) => r.json());
      if (boot.ok) setData(boot.data);
    }
  }

  const sidebar = (
    <div className="flex h-full flex-col bg-[#101114]">
      <div className="px-4 pb-3 pt-4">
        <Logo />
      </div>
      <Link href="/account?tab=wallet" className="mx-3 mb-2 overflow-hidden rounded-xl">
        <div className="nx-gradient px-3 py-3 text-black">
          <p className="text-[11px] font-bold uppercase tracking-wide">First demo deposit</p>
          <p className="font-display text-2xl font-black">200% BOOST</p>
          <p className="text-[11px]">Simulated credits only</p>
        </div>
      </Link>
      <Link href="/promotions" className="mx-3 mb-2 overflow-hidden rounded-xl border border-[#2a2c34] bg-[url('/images/promo-invite.jpg')] bg-cover">
        <div className="bg-black/65 px-3 py-3">
          <p className="text-[11px] uppercase text-[#ffb03a]">Invite friends</p>
          <p className="font-display text-lg font-bold">Share your code</p>
        </div>
      </Link>
      <button type="button" onClick={() => setCodeOpen(true)} className="mx-3 mb-4 rounded-xl border border-dashed border-[#ff7a00] px-3 py-2 text-left text-sm text-[#ff9a2e]">
        Promotion Code
      </button>
      <nav className="flex-1 overflow-y-auto px-2 pb-6">
        {NAV.map((item) => {
          const active = pathname === item.href.split("?")[0] && (item.href === "/" ? pathname === "/" : pathname.startsWith(item.href.split("?")[0]));
          const Icon = item.icon;
          return (
            <Link
              key={item.key + item.href}
              href={item.href}
              className={`mb-1 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm ${active ? "bg-[#ff7a00]/15 text-[#ff9a2e]" : "text-[#d5d5de] hover:bg-white/5"}`}
            >
              <Icon />
              <span>{t[item.key]}</span>
            </Link>
          );
        })}
        {staff ? (
          <Link href="/admin" className="mb-1 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-[#e8b923] hover:bg-white/5">
            <Icons.shield />
            Admin
          </Link>
        ) : null}
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#070708]">
      <div className="sticky top-0 z-40 bg-[#c2410c] px-3 py-1.5 text-center text-[11px] font-semibold text-white sm:text-xs">
        {t.demoBanner}
      </div>
      <aside className="fixed bottom-0 left-0 top-[28px] z-30 hidden w-[188px] border-r border-[#2a2c34] lg:block">{sidebar}</aside>
      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button className="absolute inset-0 bg-black/70" aria-label="Close menu" onClick={() => setOpen(false)} />
          <div className="absolute bottom-0 left-0 top-0 w-[260px] border-r border-[#2a2c34]">{sidebar}</div>
        </div>
      ) : null}
      <div className="lg:pl-[188px]">
        <header className="sticky top-[28px] z-20 flex items-center gap-2 border-b border-[#2a2c34] bg-[#070708]/95 px-3 py-2 backdrop-blur sm:px-5">
          <button type="button" className="nx-btn nx-btn-ghost h-10 w-10 p-0 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Icons.menu />
          </button>
          <div className="lg:hidden">
            <Logo compact />
          </div>
          <form action="/games" className="relative mx-auto hidden max-w-xl flex-1 md:block">
            <Icons.search className="pointer-events-none absolute left-3 top-2.5 text-[#9a9aa8]" />
            <input name="q" placeholder={t.search} className="nx-input pl-9" />
          </form>
          <div className="ml-auto flex items-center gap-2">
            <select
              value={lang}
              onChange={(e) => switchLang(e.target.value as Lang)}
              className="nx-input w-auto py-2 text-sm"
              aria-label="Language"
            >
              <option value="en">English</option>
              <option value="bn">বাংলা</option>
            </select>
            {data?.user ? (
              <>
                <Link href="/account?tab=wallet" className="hidden rounded-lg border border-[#2a2c34] px-3 py-2 text-sm sm:block">
                  <span className="text-[#9a9aa8]">{t.balance}</span>{" "}
                  <strong className="text-[#e8b923]">{data.demoBalanceLabel} NXC</strong>
                </Link>
                <Link href="/account" className="nx-btn nx-btn-ghost">
                  <Icons.user /> {data.user.displayName}
                </Link>
                <button type="button" className="nx-btn nx-btn-ghost" onClick={logout}>
                  {t.logout}
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="nx-btn nx-btn-ghost">
                  {t.login}
                </Link>
                <Link href="/register" className="nx-btn">
                  {t.register}
                </Link>
              </>
            )}
          </div>
        </header>
        <main className="px-3 pb-24 pt-4 sm:px-5">{children}</main>
        <SiteFooter />
      </div>
      <Floating social={social} showTop={showTop} />
      <MobileDock />
      {codeOpen ? (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-black/70 p-4">
          <div className="nx-card w-full max-w-md p-5">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-xl font-bold">Promotion code</h3>
              <button type="button" onClick={() => setCodeOpen(false)} aria-label="Close">
                <Icons.close />
              </button>
            </div>
            <p className="mb-3 text-sm text-[#9a9aa8]">Demo codes credit simulated NXC only. Try WELCOME100 or NEXORA50.</p>
            <input className="nx-input mb-3" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Enter code" />
            {codeMsg ? <p className="mb-3 text-sm text-[#ffb03a]">{codeMsg}</p> : null}
            <button type="button" className="nx-btn w-full" onClick={redeem}>
              Redeem simulated bonus
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-[#2a2c34] bg-[#101114] px-4 py-10 text-sm text-[#9a9aa8]">
      <div className="mx-auto grid max-w-6xl gap-8 md:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs">
            Nexora is an entertainment lobby in demo mode. It is not a licensed casino and does not process real-money wagers.
          </p>
        </div>
        <div className="space-y-2">
          <p className="font-semibold text-white">Platform</p>
          <Link href="/legal/about" className="block hover:text-white">About Us</Link>
          <Link href="/legal/contact" className="block hover:text-white">Contact Us</Link>
          <Link href="/support" className="block hover:text-white">Help Center</Link>
          <Link href="/download" className="block hover:text-white">App Download</Link>
        </div>
        <div className="space-y-2">
          <p className="font-semibold text-white">Policies</p>
          <Link href="/legal/terms" className="block hover:text-white">Terms and Conditions</Link>
          <Link href="/legal/privacy" className="block hover:text-white">Privacy Policy</Link>
          <Link href="/legal/responsible" className="block hover:text-white">Responsible Gaming</Link>
        </div>
        <div className="space-y-2">
          <p className="font-semibold text-white">Notices</p>
          <p>18+ only. Age verification is required before demo play.</p>
          <p>Provider tiles show genuine connection status. Missing credentials are labeled as such.</p>
          <p>© {new Date().getFullYear()} Nexora Entertainment. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

function Floating({
  social,
  showTop,
}: {
  social?: Bootstrap["social"];
  showTop: boolean;
}) {
  const items = useMemo(
    () => [
      { href: social?.whatsapp, icon: Icons.whatsapp, label: "WhatsApp" },
      { href: social?.telegram, icon: Icons.telegram, label: "Telegram" },
      { href: social?.facebook, icon: Icons.facebook, label: "Facebook" },
    ],
    [social],
  );
  return (
    <div className="fixed bottom-24 right-3 z-30 flex flex-col gap-2 sm:bottom-6">
      <Link href="/promotions" className="nx-gradient grid h-12 w-12 place-items-center rounded-full text-black shadow-lg" aria-label="Promotions">
        <Icons.gift />
      </Link>
      {items.map((item) =>
        item.href ? (
          <a
            key={item.label}
            href={item.href}
            target="_blank"
            rel="noreferrer"
            className="grid h-12 w-12 place-items-center rounded-full border border-[#2a2c34] bg-[#16171c]"
            aria-label={item.label}
          >
            <item.icon />
          </a>
        ) : (
          <button
            key={item.label}
            type="button"
            title={`${item.label} contact is not configured`}
            className="grid h-12 w-12 place-items-center rounded-full border border-[#2a2c34] bg-[#16171c] text-[#5b5b66]"
          >
            <item.icon />
          </button>
        ),
      )}
      <Link href="/support" className="grid h-12 w-12 place-items-center rounded-full border border-[#2a2c34] bg-[#16171c]" aria-label="Live support">
        <Icons.chat />
      </Link>
      {showTop ? (
        <button
          type="button"
          className="grid h-12 w-12 place-items-center rounded-full border border-[#2a2c34] bg-[#16171c]"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
        >
          <Icons.top />
        </button>
      ) : null}
    </div>
  );
}

function MobileDock() {
  const pathname = usePathname();
  const items = [
    { href: "/", label: "Home", icon: Icons.home },
    { href: "/games", label: "Games", icon: Icons.grid },
    { href: "/sports", label: "Sports", icon: Icons.sports },
    { href: "/promotions", label: "Promo", icon: Icons.megaphone },
    { href: "/account", label: "Me", icon: Icons.user },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-[#2a2c34] bg-[#101114] px-1 py-1 lg:hidden">
      {items.map((item) => {
        const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
        return (
          <Link key={item.href} href={item.href} className={`grid place-items-center py-2 text-[11px] ${active ? "text-[#ff9a2e]" : "text-[#9a9aa8]"}`}>
            <item.icon />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

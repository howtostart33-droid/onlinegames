"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { Icons } from "@/components/icons";
import type { GameItem } from "@/lib/types";

export function statusLabel(status: string) {
  if (status === "demo") return "DEMO";
  if (status === "maintenance") return "MAINTENANCE";
  if (status === "coming_soon") return "COMING SOON";
  if (status === "restricted") return "RESTRICTED";
  return status.toUpperCase();
}

export function GameArt({ game, className = "" }: { game: GameItem; className?: string }) {
  if (game.thumbnailUrl) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={game.thumbnailUrl} alt={game.name} className={`h-full w-full object-cover ${className}`} />
    );
  }
  return (
    <div className={`game-art flex h-full w-full items-end p-3 ${className}`} style={{ ["--hue" as string]: game.artHue }}>
      <div>
        <p className="font-display text-lg font-bold leading-tight">{game.name}</p>
        <p className="text-[11px] uppercase tracking-wide text-white/70">{game.provider?.name ?? "Nexora"}</p>
      </div>
    </div>
  );
}

export function GameCard({
  game,
  onFav,
}: {
  game: GameItem;
  onFav?: (game: GameItem) => void;
}) {
  const locked = game.status !== "demo";
  return (
    <div className="group relative w-[132px] shrink-0 sm:w-[148px]">
      <Link href={`/games/${game.slug}`} className="block overflow-hidden rounded-xl border border-[#2a2c34] bg-[#16171c]">
        <div className="relative aspect-[3/4] overflow-hidden">
          <GameArt game={game} className="transition duration-300 group-hover:scale-105" />
          <div className="absolute left-2 top-2 flex flex-col gap-1">
            {game.isHot ? <span className="rounded bg-[#ff7a00] px-1.5 py-0.5 text-[10px] font-bold">HOT</span> : null}
            {game.isNew ? <span className="rounded bg-[#e8b923] px-1.5 py-0.5 text-[10px] font-bold text-black">NEW</span> : null}
          </div>
          {locked ? (
            <div className="absolute inset-x-0 bottom-0 bg-black/65 px-2 py-1 text-center text-[10px] font-semibold tracking-wide text-white">
              {statusLabel(game.status)}
            </div>
          ) : (
            <div className="absolute inset-x-0 bottom-0 bg-black/55 px-2 py-1 text-center text-[10px] font-semibold tracking-wide text-[#ffb03a]">
              PLAY DEMO
            </div>
          )}
        </div>
        <div className="px-2 py-2">
          <p className="truncate text-sm font-semibold">{game.name}</p>
          <p className="truncate text-[11px] text-[#9a9aa8]">{game.provider?.name ?? "Provider"}</p>
        </div>
      </Link>
      {onFav ? (
        <button
          type="button"
          onClick={() => onFav(game)}
          className={`absolute right-2 top-2 rounded-full p-1.5 ${game.favorited ? "bg-[#ff7a00] text-black" : "bg-black/55 text-white"}`}
          aria-label="Toggle favorite"
        >
          <Icons.heart />
        </button>
      ) : null}
    </div>
  );
}

export function GameCarousel({
  title,
  href,
  games,
  loading,
  error,
  onRetry,
  onFav,
}: {
  title: string;
  href: string;
  games: GameItem[];
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  onFav?: (game: GameItem) => void;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => {
    scroller.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
  };
  return (
    <section className="mb-7">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="font-display text-xl font-bold uppercase tracking-wide">{title}</h2>
        <div className="flex items-center gap-2">
          <Link href={href} className="text-sm font-semibold text-[#ff9a2e]">
            View More
          </Link>
          <button type="button" className="nx-btn nx-btn-ghost h-8 w-8 p-0" onClick={() => scroll(-1)} aria-label="Previous">
            <Icons.chevronL />
          </button>
          <button type="button" className="nx-btn nx-btn-ghost h-8 w-8 p-0" onClick={() => scroll(1)} aria-label="Next">
            <Icons.chevronR />
          </button>
        </div>
      </div>
      {loading ? (
        <div className="flex gap-3 overflow-hidden">
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} className="h-[220px] w-[132px] shrink-0 animate-pulse rounded-xl bg-[#1c1d24] sm:w-[148px]" />
          ))}
        </div>
      ) : error ? (
        <div className="nx-card flex items-center justify-between px-4 py-5 text-sm text-[#9a9aa8]">
          <span>{error}</span>
          {onRetry ? (
            <button type="button" className="nx-btn" onClick={onRetry}>
              Retry
            </button>
          ) : null}
        </div>
      ) : games.length === 0 ? (
        <div className="nx-card px-4 py-6 text-sm text-[#9a9aa8]">No titles in this section yet.</div>
      ) : (
        <div ref={scroller} className="no-scrollbar flex gap-3 overflow-x-auto pb-1">
          {games.map((game) => (
            <GameCard key={game.id} game={game} onFav={onFav} />
          ))}
        </div>
      )}
    </section>
  );
}

export function PromoCarousel({
  banners,
}: {
  banners: { id: string; title: string; subtitle: string; imageUrl: string; href: string }[];
}) {
  const [i, setI] = useState(0);
  if (!banners.length) return null;
  const banner = banners[i % banners.length];
  return (
    <div className="relative overflow-hidden rounded-2xl border border-[#2a2c34]">
      <Link href={banner.href} className="block">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={banner.imageUrl} alt={banner.title} className="h-[180px] w-full object-cover sm:h-[260px] lg:h-[320px]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/35 to-transparent" />
        <div className="absolute bottom-6 left-6 max-w-lg">
          <p className="mb-1 text-xs font-bold uppercase tracking-[0.18em] text-[#ffb03a]">Simulated promotion</p>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">{banner.title}</h2>
          <p className="mt-2 text-sm text-white/80">{banner.subtitle}</p>
        </div>
      </Link>
      <div className="absolute bottom-4 right-4 flex gap-2">
        {banners.map((item, idx) => (
          <button
            key={item.id}
            type="button"
            className={`h-2 w-6 rounded-full ${idx === i ? "bg-[#ff7a00]" : "bg-white/30"}`}
            onClick={() => setI(idx)}
            aria-label={`Show banner ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

export function AnnouncementTicker({ items }: { items: string[] }) {
  const text = items.length ? [...items, ...items] : ["Nexora demo mode is active."];
  return (
    <div className="mt-3 flex items-center gap-3 rounded-xl border border-[#2a2c34] bg-[#16171c] px-3 py-2">
      <span className="nx-gradient rounded px-2 py-1 text-[11px] font-bold text-black">NEWS</span>
      <div className="marquee flex-1">
        <div className="marquee-track text-sm text-[#d4d4dc]">
          {text.map((item, i) => (
            <span key={i}>{item}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

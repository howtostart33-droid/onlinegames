"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { GameCard } from "@/components/games";
import type { GameItem } from "@/lib/types";

export function SportsBoard({ sport }: { sport?: string }) {
  const [data, setData] = useState<{
    notice: string;
    lastUpdatedAt: string | null;
    events: {
      id: string;
      sport: string;
      league: string;
      homeTeam: string;
      awayTeam: string;
      startAt: string;
      status: string;
      homeScore: number | null;
      awayScore: number | null;
      isLive: boolean;
      suspended: boolean;
      dataSource: string;
      lastUpdatedAt: string;
    }[];
  } | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    const q = sport ? `?sport=${encodeURIComponent(sport)}` : "";
    fetch(`/api/v1/sports${q}`)
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) setError(j.error);
        else setData(j.data);
      });
  }, [sport]);
  if (error) return <div className="nx-card p-6">{error}</div>;
  if (!data) return <div className="nx-card h-48 animate-pulse" />;
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Sportsbook preview</h1>
      <p className="mt-2 rounded-lg border border-[#e8b923]/40 bg-[#e8b923]/10 p-3 text-sm text-[#e8b923]">{data.notice}</p>
      <p className="mt-2 text-xs text-[#9a9aa8]">Last updated: {data.lastUpdatedAt ? new Date(data.lastUpdatedAt).toLocaleString() : "n/a"}</p>
      <div className="mt-4 flex gap-2">
        {["", "Football", "Basketball", "Esports"].map((s) => (
          <Link key={s || "all"} href={s ? `/sports?sport=${s}` : "/sports"} className="nx-btn nx-btn-ghost text-sm">
            {s || "All"}
          </Link>
        ))}
      </div>
      <div className="mt-4 grid gap-3">
        {data.events.map((event) => (
          <Link key={event.id} href={`/sports/${event.id}`} className="nx-card p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-widest text-[#9a9aa8]">
                  {event.sport} · {event.league} · {event.dataSource}
                </p>
                <p className="font-display text-xl font-bold">
                  {event.homeTeam} vs {event.awayTeam}
                </p>
              </div>
              <div className="text-right">
                {event.isLive ? (
                  <span className={`rounded-full px-2 py-1 text-xs font-bold ${event.suspended ? "bg-yellow-500/20 text-yellow-300" : "bg-red-500/20 text-red-300"}`}>
                    {event.suspended ? "SUSPENDED" : "LIVE"}
                  </span>
                ) : (
                  <span className="text-sm text-[#9a9aa8]">{new Date(event.startAt).toLocaleString()}</span>
                )}
                {event.isLive ? (
                  <p className="mt-1 font-display text-2xl font-black">
                    {event.homeScore ?? 0} - {event.awayScore ?? 0}
                  </p>
                ) : null}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function SportsEvent({ id }: { id: string }) {
  const [data, setData] = useState<{
    notice: string;
    event: { homeTeam: string; awayTeam: string; league: string; suspended: boolean; isLive: boolean; homeScore: number | null; awayScore: number | null; lastUpdatedAt: string; dataSource: string };
    markets: { id: string; name: string; status: string; selections: { name: string; odds: string; suspended: boolean }[]; lastUpdatedAt: string }[];
  } | null>(null);
  useEffect(() => {
    fetch(`/api/v1/sports/${id}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setData(j.data);
      });
  }, [id]);
  if (!data) return <div className="nx-card h-48 animate-pulse" />;
  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-[#ffb03a]">{data.event.league} · {data.event.dataSource}</p>
      <h1 className="font-display text-3xl font-bold">
        {data.event.homeTeam} vs {data.event.awayTeam}
      </h1>
      {data.event.isLive ? (
        <p className="mt-2 font-display text-4xl font-black">
          {data.event.homeScore ?? 0} - {data.event.awayScore ?? 0}
        </p>
      ) : null}
      <p className="mt-3 rounded-lg border border-[#e8b923]/40 bg-[#e8b923]/10 p-3 text-sm text-[#e8b923]">{data.notice}</p>
      <p className="mt-2 text-xs text-[#9a9aa8]">Updated {new Date(data.event.lastUpdatedAt).toLocaleString()}</p>
      <div className="mt-5 grid gap-3">
        {data.markets.map((market) => (
          <div key={market.id} className="nx-card p-4">
            <div className="mb-3 flex justify-between text-sm">
              <strong>{market.name}</strong>
              <span className="uppercase text-[#9a9aa8]">{market.status}</span>
            </div>
            <div className="grid gap-2 sm:grid-cols-3">
              {market.selections.map((sel) => (
                <button key={sel.name} type="button" className="nx-btn nx-btn-ghost" disabled>
                  {sel.name}
                  <span className="text-[#e8b923]">{sel.odds}</span>
                </button>
              ))}
            </div>
            <p className="mt-2 text-xs text-[#9a9aa8]">Bet placement is disabled. Buttons are informational only.</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PromotionsPage() {
  const [rows, setRows] = useState<{ id: string; title: string; summary: string; body: string; terms: string; simulated: boolean; imageUrl: string | null; codes: string[] }[]>([]);
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");
  useEffect(() => {
    fetch("/api/v1/promotions")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setRows(j.data);
      });
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Promotions</h1>
      <p className="mt-2 text-sm text-[#9a9aa8]">Every campaign is marked simulated. Codes credit demo NXC after server-side eligibility checks.</p>
      <div className="nx-card mt-4 flex flex-col gap-2 p-4 sm:flex-row">
        <input className="nx-input" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Promotion code" />
        <button
          type="button"
          className="nx-btn"
          onClick={async () => {
            const res = await fetch("/api/v1/promotions/redeem", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ code }),
            });
            const j = await res.json();
            setMsg(j.ok ? "Simulated bonus applied." : j.error);
          }}
        >
          Redeem
        </button>
      </div>
      {msg ? <p className="mt-2 text-sm text-[#ffb03a]">{msg}</p> : null}
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {rows.map((row) => (
          <article key={row.id} className="nx-card overflow-hidden">
            {row.imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={row.imageUrl} alt="" className="h-36 w-full object-cover" />
            ) : null}
            <div className="p-4">
              <p className="text-[11px] font-bold uppercase tracking-widest text-[#ffb03a]">{row.simulated ? "Simulated" : "Live"}</p>
              <h2 className="font-display text-2xl font-bold">{row.title}</h2>
              <p className="mt-2 text-sm text-[#9a9aa8]">{row.body}</p>
              <p className="mt-3 text-xs text-[#6f6f7b]">{row.terms}</p>
              {row.codes.length ? <p className="mt-2 text-sm">Code: {row.codes.join(", ")}</p> : null}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export function VipPage() {
  const [data, setData] = useState<{ tiers: { name: string; minWagerCents: number; rebateBps: number }[]; wagered: number; current?: { name: string }; simulated: boolean } | null>(null);
  useEffect(() => {
    fetch("/api/v1/vip")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setData(j.data);
      });
  }, []);
  if (!data) return <div className="nx-card h-48 animate-pulse" />;
  return (
    <div>
      <div className="overflow-hidden rounded-2xl border border-[#2a2c34]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/vip-lounge.jpg" alt="" className="h-48 w-full object-cover" />
      </div>
      <h1 className="mt-5 font-display text-3xl font-bold">VIP path</h1>
      <p className="mt-2 text-sm text-[#9a9aa8]">Simulated loyalty track based on demo wagers. Current tier: {data.current?.name ?? "Bronze"}.</p>
      <div className="mt-5 grid gap-3 md:grid-cols-5">
        {data.tiers.map((tier) => (
          <div key={tier.name} className="nx-card p-4">
            <p className="font-display text-xl font-bold">{tier.name}</p>
            <p className="text-sm text-[#9a9aa8]">From {(tier.minWagerCents / 100).toFixed(0)} NXC wagered</p>
            <p className="mt-2 text-[#e8b923]">{(tier.rebateBps / 100).toFixed(2)}% rebate preview</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function FavoritesPage() {
  const [items, setItems] = useState<GameItem[] | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    fetch("/api/v1/me/favorites")
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) setError(j.error);
        else setItems(j.data);
      });
  }, []);
  if (error) {
    return (
      <div className="nx-card p-6">
        {error} <Link href="/login" className="text-[#ff9a2e]">Login</Link>
      </div>
    );
  }
  if (!items) return <div className="nx-card h-40 animate-pulse" />;
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Favorites</h1>
      {items.length === 0 ? (
        <p className="mt-4 text-[#9a9aa8]">No favorites yet.</p>
      ) : (
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {items.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      )}
    </div>
  );
}

export function AccountPage() {
  const [tab, setTab] = useState("profile");
  const [me, setMe] = useState<{
    user: { displayName: string; email: string; referralCode: string; ageVerified: boolean; dateOfBirth: string | null; country: string | null };
    wallets: { demo: { availableCents: number; currency: string } | null; real: { status: string; lockedReason: string } | null };
    limits: { dailyDepositCents: number | null; sessionMinutes: number | null; reminderMinutes: number } | null;
    notifications: { id: string; title: string; body: string }[];
    sessions: { id: string; userAgent: string | null; ip: string | null; createdAt: string; revokedAt: string | null }[];
  } | null>(null);
  const [txs, setTxs] = useState<{ id: string; type: string; amountCents: number; reason: string | null; createdAt: string }[]>([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setTab(params.get("tab") || "profile");
    fetch("/api/v1/me")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setMe(j.data);
      });
    fetch("/api/v1/me/transactions")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setTxs(j.data);
      });
  }, []);

  if (!me) {
    return (
      <div className="nx-card p-6">
        Login required. <Link className="text-[#ff9a2e]" href="/login">Go to login</Link>
      </div>
    );
  }

  async function money(kind: "deposit" | "withdraw") {
    const amount = Number(prompt("Amount in NXC", "50"));
    if (!amount) return;
    const res = await fetch(kind === "deposit" ? "/api/v1/me/deposit" : "/api/v1/me/withdraw", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ amountCents: Math.round(amount * 100), idempotencyKey: crypto.randomUUID() }),
    });
    const j = await res.json();
    setMsg(j.ok ? `Simulated ${kind} complete.` : j.error);
    const meRes = await fetch("/api/v1/me").then((r) => r.json());
    if (meRes.ok) setMe(meRes.data);
    const txRes = await fetch("/api/v1/me/transactions").then((r) => r.json());
    if (txRes.ok) setTxs(txRes.data);
  }

  const tabs = [
    ["profile", "Profile"],
    ["wallet", "Wallet"],
    ["rewards", "Rewards"],
    ["rebates", "Rebates"],
    ["responsible", "Responsible"],
  ];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">My account</h1>
      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto">
        {tabs.map(([id, label]) => (
          <button key={id} type="button" className={`nx-btn ${tab === id ? "" : "nx-btn-ghost"}`} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>
      {msg ? <p className="mt-3 text-sm text-[#ffb03a]">{msg}</p> : null}
      {tab === "profile" ? (
        <div className="nx-card mt-4 p-5">
          <p><strong>{me.user.displayName}</strong> · {me.user.email}</p>
          <p className="mt-2 text-sm">Referral code: {me.user.referralCode}</p>
          <p className="mt-2 text-sm">Age verified: {me.user.ageVerified ? "Yes" : "No"}</p>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {me.sessions.map((s) => (
              <div key={s.id} className="rounded-lg border border-[#2a2c34] p-3 text-xs text-[#9a9aa8]">
                {s.userAgent || "Unknown device"} · {s.ip || "ip n/a"}
                <div>{s.revokedAt ? "revoked" : "active"} · {new Date(s.createdAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <p className="font-semibold">Notifications</p>
            {me.notifications.map((n) => (
              <p key={n.id} className="mt-1 text-sm text-[#9a9aa8]">
                {n.title} — {n.body}
              </p>
            ))}
          </div>
        </div>
      ) : null}
      {tab === "wallet" ? (
        <div className="nx-card mt-4 p-5">
          <p className="text-sm text-[#9a9aa8]">Demo wallet</p>
          <p className="font-display text-4xl font-black text-[#e8b923]">
            {((me.wallets.demo?.availableCents ?? 0) / 100).toFixed(2)} {me.wallets.demo?.currency}
          </p>
          <p className="mt-3 rounded-lg bg-white/5 p-3 text-sm">{me.wallets.real?.lockedReason}</p>
          <div className="mt-4 flex gap-3">
            <button type="button" className="nx-btn" onClick={() => money("deposit")}>
              Simulated deposit
            </button>
            <button type="button" className="nx-btn nx-btn-ghost" onClick={() => money("withdraw")}>
              Simulated withdrawal
            </button>
          </div>
          <div className="mt-5">
            {txs.map((tx) => (
              <div key={tx.id} className="flex justify-between border-t border-[#2a2c34] py-2 text-sm">
                <span>
                  {tx.type} · {tx.reason}
                </span>
                <span>{(tx.amountCents / 100).toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>
      ) : null}
      {tab === "rewards" || tab === "rebates" ? (
        <div className="nx-card mt-4 p-5">
          <p className="text-sm text-[#9a9aa8]">
            {tab === "rewards"
              ? "Rewards stay simulated. Redeem WELCOME100 or NEXORA50 from Promotions."
              : "Rebate percentages follow the VIP path and never settle to a cash wallet."}
          </p>
          <Link href="/promotions" className="mt-3 inline-block text-[#ff9a2e]">
            Open promotions
          </Link>
        </div>
      ) : null}
      {tab === "responsible" ? (
        <div className="nx-card mt-4 space-y-3 p-5">
          <p>Limits, cooling-off, self-exclusion, and account closure are enforced on the server.</p>
          <button
            type="button"
            className="nx-btn nx-btn-ghost"
            onClick={async () => {
              await fetch("/api/v1/me/responsible", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ action: "limits", dailyDepositCents: 20000, reminderMinutes: 45 }),
              });
              setMsg("Limits saved.");
            }}
          >
            Set 200 NXC daily demo deposit cap
          </button>
          <button
            type="button"
            className="nx-btn nx-btn-ghost"
            onClick={async () => {
              await fetch("/api/v1/me/responsible", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ action: "cool-off", hours: 24 }),
              });
              setMsg("24h cooling-off enabled.");
            }}
          >
            24h cooling-off
          </button>
          <button
            type="button"
            className="nx-btn nx-btn-ghost"
            onClick={async () => {
              if (!confirm("Self-exclude and sign out?")) return;
              await fetch("/api/v1/me/responsible", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ action: "self-exclude", days: 7 }),
              });
              window.location.href = "/";
            }}
          >
            7-day self-exclusion
          </button>
        </div>
      ) : null}
    </div>
  );
}

export function SupportPage() {
  const [tickets, setTickets] = useState<{ id: string; subject: string; status: string; createdAt: string }[]>([]);
  const [msg, setMsg] = useState("");
  useEffect(() => {
    fetch("/api/v1/me/tickets")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setTickets(j.data);
      });
  }, []);
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div>
        <h1 className="font-display text-3xl font-bold">Help Center</h1>
        <div className="mt-4 space-y-3">
          {[
            ["Is this real-money gambling?", "No. Nexora is demo-only until licensing, provider authorization, and payment approval are complete."],
            ["Why are some games coming soon?", "Those titles belong to adapters that do not have credentials. We never embed unauthorized clients."],
            ["How do sports odds work?", "Fixture samples with timestamps. Live odds require a licensed sports API."],
            ["How do I contact support?", "Open a ticket here. WhatsApp/Telegram stay disabled until an authorized URL is configured."],
          ].map(([q, a]) => (
            <div key={q} className="nx-card p-4">
              <p className="font-semibold">{q}</p>
              <p className="mt-1 text-sm text-[#9a9aa8]">{a}</p>
            </div>
          ))}
        </div>
      </div>
      <form
        className="nx-card p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          const form = new FormData(e.currentTarget);
          const res = await fetch("/api/v1/support/tickets", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ subject: form.get("subject"), message: form.get("message") }),
          });
          const j = await res.json();
          setMsg(j.ok ? "Ticket opened." : j.error);
          const list = await fetch("/api/v1/me/tickets").then((r) => r.json());
          if (list.ok) setTickets(list.data);
        }}
      >
        <h2 className="font-display text-2xl font-bold">Open a ticket</h2>
        <input className="nx-input mt-3" name="subject" required placeholder="Subject" />
        <textarea className="nx-input mt-3 min-h-32" name="message" required placeholder="How can we help?" />
        <button className="nx-btn mt-4">Submit</button>
        {msg ? <p className="mt-2 text-sm text-[#ffb03a]">{msg}</p> : null}
        <div className="mt-5 space-y-2 text-sm">
          {tickets.map((t) => (
            <div key={t.id} className="rounded border border-[#2a2c34] p-2">
              {t.subject} · {t.status}
            </div>
          ))}
        </div>
      </form>
    </div>
  );
}

export function AdminPage() {
  const [tab, setTab] = useState("overview");
  const [dash, setDash] = useState<{ users: number; games: number; openTickets: number; transactions: number; providers: { name: string; status: string; healthMessage: string | null }[]; audit: { id: string; action: string; createdAt: string }[] } | null>(null);
  const [users, setUsers] = useState<{ id: string; email: string; displayName: string; role: string; status: string }[]>([]);
  const [error, setError] = useState("");
  const [txs, setTxs] = useState<{ txs: { id: string; type: string; amountCents: number; reason: string | null }[] } | null>(null);
  const [tickets, setTickets] = useState<{ id: string; subject: string; status: string }[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [audit, setAudit] = useState<{ id: string; action: string; entity: string; createdAt: string }[]>([]);
  const [games, setGames] = useState<{ id: string; name: string; status: string; isHot: boolean; isRecommended: boolean }[]>([]);

  useEffect(() => {
    fetch("/api/v1/admin/dashboard")
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) setError(j.error);
        else setDash(j.data);
      });
  }, []);

  useEffect(() => {
    if (tab === "users") {
      fetch("/api/v1/admin/users")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setUsers(j.data);
          else setError(j.error);
        });
    }
    if (tab === "finance") {
      fetch("/api/v1/admin/transactions")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setTxs(j.data);
          else setError(j.error);
        });
    }
    if (tab === "support") {
      fetch("/api/v1/admin/tickets")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setTickets(j.data);
          else setError(j.error);
        });
    }
    if (tab === "system") {
      fetch("/api/v1/admin/settings")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setSettings(j.data);
          else setError(j.error);
        });
      fetch("/api/v1/admin/audit-logs")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setAudit(j.data);
        });
    }
    if (tab === "catalog") {
      fetch("/api/v1/admin/games")
        .then((r) => r.json())
        .then((j) => {
          if (j.ok) setGames(j.data);
          else setError(j.error);
        });
    }
  }, [tab]);

  if (error && !dash) {
    return (
      <div className="nx-card p-6">
        {error} Staff login required.
      </div>
    );
  }
  if (!dash) return <div className="nx-card h-48 animate-pulse" />;

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Operations</h1>
      <p className="text-sm text-[#9a9aa8]">Live backend data. Least-privilege roles are enforced server-side.</p>
      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto">
        {["overview", "users", "catalog", "finance", "support", "system"].map((id) => (
          <button key={id} type="button" className={`nx-btn ${tab === id ? "" : "nx-btn-ghost"}`} onClick={() => setTab(id)}>
            {id}
          </button>
        ))}
      </div>
      {error ? <p className="mt-3 text-sm text-red-400">{error}</p> : null}
      {tab === "overview" ? (
        <div className="mt-5 grid gap-3 md:grid-cols-4">
          {[
            ["Users", dash.users],
            ["Games", dash.games],
            ["Open tickets", dash.openTickets],
            ["Ledger rows", dash.transactions],
          ].map(([k, v]) => (
            <div key={String(k)} className="nx-card p-4">
              <p className="text-xs uppercase text-[#9a9aa8]">{k}</p>
              <p className="font-display text-3xl font-black">{v}</p>
            </div>
          ))}
          <div className="nx-card md:col-span-4 p-4">
            <p className="mb-3 font-semibold">Providers</p>
            {dash.providers.map((p) => (
              <p key={p.name} className="text-sm text-[#9a9aa8]">
                {p.name}: {p.status} — {p.healthMessage}
              </p>
            ))}
          </div>
        </div>
      ) : null}
      {tab === "users" ? (
        <div className="nx-card mt-4 overflow-x-auto p-4">
          {users.map((u) => (
            <div key={u.id} className="flex items-center justify-between border-b border-[#2a2c34] py-2 text-sm">
              <span>
                {u.displayName} · {u.email} · {u.role}
              </span>
              <select
                className="nx-input w-auto"
                defaultValue={u.status}
                onChange={async (e) => {
                  await fetch("/api/v1/admin/users/status", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ userId: u.id, status: e.target.value }),
                  });
                }}
              >
                <option>active</option>
                <option>suspended</option>
                <option>closed</option>
                <option>pending_verification</option>
              </select>
            </div>
          ))}
        </div>
      ) : null}
      {tab === "catalog" ? (
        <div className="nx-card mt-4 p-4">
          <button
            type="button"
            className="nx-btn mb-4"
            onClick={async () => {
              await fetch("/api/v1/admin/providers/sync", { method: "POST" });
              setError("");
              alert("Provider health refreshed. External catalogs stay empty without credentials.");
            }}
          >
            Sync providers
          </button>
          {games.map((g) => (
            <label key={g.id} className="flex items-center justify-between border-b border-[#2a2c34] py-2 text-sm">
              <span>
                {g.name} · {g.status}
              </span>
              <input
                type="checkbox"
                defaultChecked={g.isHot}
                onChange={async (e) => {
                  await fetch("/api/v1/admin/games/patch", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ id: g.id, isHot: e.target.checked, isRecommended: g.isRecommended, status: g.status }),
                  });
                }}
              />
            </label>
          ))}
        </div>
      ) : null}
      {tab === "finance" ? (
        <div className="nx-card mt-4 p-4">
          {txs?.txs.map((tx) => (
            <div key={tx.id} className="flex justify-between border-b border-[#2a2c34] py-2 text-sm">
              <span>
                {tx.type} · {tx.reason}
              </span>
              <span>{(tx.amountCents / 100).toFixed(2)}</span>
            </div>
          ))}
        </div>
      ) : null}
      {tab === "support" ? (
        <div className="nx-card mt-4 p-4">
          {tickets.map((t) => (
            <div key={t.id} className="border-b border-[#2a2c34] py-2 text-sm">
              {t.subject} · {t.status}
              <button
                type="button"
                className="ml-3 text-[#ff9a2e]"
                onClick={async () => {
                  const message = prompt("Reply");
                  if (!message) return;
                  await fetch("/api/v1/admin/tickets/reply", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ ticketId: t.id, message, status: "pending" }),
                  });
                }}
              >
                Reply
              </button>
            </div>
          ))}
        </div>
      ) : null}
      {tab === "system" ? (
        <div className="nx-card mt-4 space-y-3 p-4">
          {Object.entries(settings).map(([k, v]) => (
            <label key={k} className="block text-sm">
              {k}
              <input
                className="nx-input mt-1"
                defaultValue={v}
                onBlur={async (e) => {
                  await fetch("/api/v1/admin/settings", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ settings: { [k]: e.target.value } }),
                  });
                }}
              />
            </label>
          ))}
          <div>
            {audit.map((row) => (
              <p key={row.id} className="text-xs text-[#9a9aa8]">
                {new Date(row.createdAt).toLocaleString()} · {row.action} · {row.entity}
              </p>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { AnnouncementTicker, GameCard, GameCarousel, PromoCarousel } from "@/components/games";
import { Icons } from "@/components/icons";
import type { Bootstrap, CategoryInfo, GameItem } from "@/lib/types";

const CATS = [
  { slug: "hot", label: "Hot", icon: Icons.flame },
  { slug: "slots", label: "Slots", icon: Icons.slots },
  { slug: "live", label: "Live", icon: Icons.live },
  { slug: "sports", label: "Sports", icon: Icons.sports, href: "/sports" },
  { slug: "esports", label: "E-Sports", icon: Icons.esports, href: "/sports?sport=Esports" },
  { slug: "fish", label: "Fish", icon: Icons.fish },
  { slug: "arcade", label: "Arcade", icon: Icons.arcade },
  { slug: "lottery", label: "Lottery", icon: Icons.lottery },
  { slug: "cockfight", label: "Cockfight", icon: Icons.hold },
];

async function loadGames(params: string) {
  const res = await fetch(`/api/v1/games/search?${params}`);
  const json = await res.json();
  if (!json.ok) throw new Error(json.error || "Unable to load games");
  return json.data as { items: GameItem[]; total: number };
}

export function Lobby({ bootstrap }: { bootstrap: Bootstrap }) {
  const [hot, setHot] = useState<GameItem[]>([]);
  const [rec, setRec] = useState<GameItem[]>([]);
  const [slots, setSlots] = useState<GameItem[]>([]);
  const [live, setLive] = useState<GameItem[]>([]);
  const [fish, setFish] = useState<GameItem[]>([]);
  const [arcade, setArcade] = useState<GameItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [a, b, c, d, e, f] = await Promise.all([
        loadGames("filter=hot&pageSize=16"),
        loadGames("filter=recommended&pageSize=16"),
        loadGames("category=slots&pageSize=16"),
        loadGames("category=live&pageSize=16"),
        loadGames("category=fish&pageSize=16"),
        loadGames("category=arcade&pageSize=16"),
      ]);
      setHot(a.items);
      setRec(b.items);
      setSlots(c.items);
      setLive(d.items);
      setFish(e.items);
      setArcade(f.items);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Load failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function onFav(game: GameItem) {
    if (!bootstrap.user) {
      window.location.href = "/login";
      return;
    }
    const method = game.favorited ? "DELETE" : "POST";
    await fetch(`/api/v1/me/favorites/${game.id}`, { method });
    const flip = (list: GameItem[]) => list.map((item) => (item.id === game.id ? { ...item, favorited: !item.favorited } : item));
    setHot(flip);
    setRec(flip);
    setSlots(flip);
    setLive(flip);
    setFish(flip);
    setArcade(flip);
  }

  const lottery = bootstrap.categories.find((c) => c.slug === "lottery");
  const cockfight = bootstrap.categories.find((c) => c.slug === "cockfight");

  return (
    <div>
      <PromoCarousel banners={bootstrap.banners} />
      <AnnouncementTicker items={bootstrap.announcements} />
      <form action="/games" className="relative mt-3 md:hidden">
        <Icons.search className="pointer-events-none absolute left-3 top-2.5 text-[#9a9aa8]" />
        <input name="q" placeholder="Search games, providers, categories" className="nx-input pl-9" />
      </form>
      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-2">
        {CATS.map((cat) => {
          const Icon = cat.icon;
          return (
            <Link
              key={cat.slug}
              href={cat.href ?? `/games?category=${cat.slug}`}
              className="flex min-w-[76px] flex-col items-center gap-1 rounded-xl border border-[#2a2c34] bg-[#16171c] px-3 py-3 text-xs font-semibold"
            >
              <span className="text-lg text-[#ff9a2e]">
                <Icon />
              </span>
              {cat.label}
            </Link>
          );
        })}
      </div>
      <div className="mt-5">
        <GameCarousel title="Hot Games" href="/games?filter=hot" games={hot} loading={loading} error={error} onRetry={load} onFav={onFav} />
        <GameCarousel title="Recommended" href="/games?filter=recommended" games={rec} loading={loading} onFav={onFav} />
        <GameCarousel title="Slots" href="/games?category=slots" games={slots} loading={loading} onFav={onFav} />
        <GameCarousel title="Live Casino" href="/games?category=live" games={live} loading={loading} onFav={onFav} />
        <section className="mb-7">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold uppercase tracking-wide">Sports</h2>
            <Link href="/sports" className="text-sm font-semibold text-[#ff9a2e]">
              View More
            </Link>
          </div>
          <Link href="/sports" className="relative block overflow-hidden rounded-2xl border border-[#2a2c34]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/hero-sports.jpg" alt="Sports fixtures" className="h-40 w-full object-cover sm:h-52" />
            <div className="absolute inset-0 bg-black/45 p-5">
              <p className="text-xs font-bold uppercase tracking-widest text-[#ffb03a]">Fixture data</p>
              <p className="font-display text-3xl font-bold">Live sports preview</p>
              <p className="mt-1 max-w-lg text-sm text-white/80">Sample matches only. Odds are not live and real-money betting is disabled.</p>
            </div>
          </Link>
        </section>
        <GameCarousel title="Fish Games" href="/games?category=fish" games={fish} loading={loading} onFav={onFav} />
        <GameCarousel title="Crash & Arcade" href="/games?category=arcade" games={arcade} loading={loading} onFav={onFav} />
        <LegalHold category={lottery} />
        <LegalHold category={cockfight} />
      </div>
      <ProviderStrip providers={bootstrap.providers} />
    </div>
  );
}

function LegalHold({ category }: { category?: CategoryInfo }) {
  if (!category) return null;
  return (
    <section className="mb-7">
      <h2 className="mb-3 font-display text-xl font-bold uppercase tracking-wide">{category.name}</h2>
      <div className="nx-card p-5">
        <p className="font-semibold text-[#e8b923]">Unavailable pending legal approval</p>
        <p className="mt-2 text-sm text-[#9a9aa8]">{category.legalNote}</p>
      </div>
    </section>
  );
}

function ProviderStrip({ providers }: { providers: Bootstrap["providers"] }) {
  return (
    <section className="mb-8">
      <h2 className="mb-3 font-display text-xl font-bold uppercase tracking-wide">Game providers</h2>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {providers.map((p) => (
          <div key={p.id} className="nx-card p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold">{p.name}</p>
              <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold uppercase ${p.status === "demo" ? "bg-[#ff7a00]/20 text-[#ff9a2e]" : p.status === "missing_credentials" ? "bg-white/10 text-[#9a9aa8]" : "bg-emerald-500/15 text-emerald-300"}`}>
                {p.status.replace("_", " ")}
              </span>
            </div>
            <p className="mt-2 text-xs text-[#9a9aa8]">{p.healthMessage}</p>
            {p.lastHealthCheck ? (
              <p className="mt-2 text-[11px] text-[#6f6f7b]">Checked {new Date(p.lastHealthCheck).toLocaleString()}</p>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
}

export function Catalog({
  initialQ,
  initialCategory,
  initialFilter,
}: {
  initialQ?: string;
  initialCategory?: string;
  initialFilter?: string;
}) {
  const [q, setQ] = useState(initialQ ?? "");
  const [category, setCategory] = useState(initialCategory ?? "");
  const [filter, setFilter] = useState(initialFilter ?? "");
  const [sort, setSort] = useState("popular");
  const [provider, setProvider] = useState("");
  const [items, setItems] = useState<GameItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [providers, setProviders] = useState<{ code: string; name: string }[]>([]);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (category) p.set("category", category);
    if (filter) p.set("filter", filter);
    if (sort) p.set("sort", sort);
    if (provider) p.set("provider", provider);
    p.set("page", String(page));
    p.set("pageSize", "24");
    return p.toString();
  }, [q, category, filter, sort, provider, page]);

  useEffect(() => {
    fetch("/api/v1/providers")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setProviders(j.data);
      });
  }, []);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetch(`/api/v1/games/search?${query}`)
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) throw new Error(j.error);
        setItems(j.data.items);
        setTotal(j.data.total);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [query]);

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Game lobby</h1>
      <p className="mt-1 text-sm text-[#9a9aa8]">Search updates without reloading. Unavailable titles stay in coming-soon or maintenance state.</p>
      <div className="mt-4 grid gap-3 md:grid-cols-4">
        <input className="nx-input md:col-span-2" value={q} onChange={(e) => { setPage(1); setQ(e.target.value); }} placeholder="Search by name" />
        <select className="nx-input" value={category} onChange={(e) => { setPage(1); setCategory(e.target.value); }}>
          <option value="">All categories</option>
          <option value="slots">Slots</option>
          <option value="live">Live</option>
          <option value="fish">Fish</option>
          <option value="arcade">Arcade</option>
        </select>
        <select className="nx-input" value={provider} onChange={(e) => { setPage(1); setProvider(e.target.value); }}>
          <option value="">All providers</option>
          {providers.map((p) => (
            <option key={p.code} value={p.code}>
              {p.name}
            </option>
          ))}
        </select>
        <select className="nx-input" value={filter} onChange={(e) => { setPage(1); setFilter(e.target.value); }}>
          <option value="">Any collection</option>
          <option value="hot">Popular</option>
          <option value="recommended">Recommended</option>
          <option value="new">New releases</option>
          <option value="favorites">Favorites</option>
          <option value="recent">Recently played</option>
        </select>
        <select className="nx-input" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="popular">Sort: popular</option>
          <option value="new">Sort: newest</option>
          <option value="name">Sort: name</option>
        </select>
      </div>
      {loading ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="aspect-[3/4] animate-pulse rounded-xl bg-[#1c1d24]" />
          ))}
        </div>
      ) : error ? (
        <div className="nx-card mt-6 p-5">{error}</div>
      ) : items.length === 0 ? (
        <div className="nx-card mt-6 p-6 text-[#9a9aa8]">No games match those filters.</div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {items.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      )}
      <div className="mt-6 flex items-center justify-between text-sm text-[#9a9aa8]">
        <span>{total} titles</span>
        <div className="flex gap-2">
          <button type="button" className="nx-btn nx-btn-ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Previous
          </button>
          <button type="button" className="nx-btn nx-btn-ghost" disabled={page * 24 >= total} onClick={() => setPage((p) => p + 1)}>
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export function AuthForm({ mode }: { mode: "login" | "register" | "forgot" }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError("");
    setNotice("");
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const url =
      mode === "login" ? "/api/v1/auth/login" : mode === "register" ? "/api/v1/auth/register" : "/api/v1/auth/forgot-password";
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    const json = await res.json();
    setPending(false);
    if (!json.ok) {
      setError(json.error || "Request failed");
      return;
    }
    if (mode === "forgot") {
      setNotice(json.data.demoToken ? `${json.data.notice} Token: ${json.data.demoToken}` : json.data.message);
      return;
    }
    router.push("/");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="nx-card mx-auto w-full max-w-md p-6">
      <h1 className="font-display text-3xl font-bold">
        {mode === "login" ? "Welcome back" : mode === "register" ? "Create account" : "Reset password"}
      </h1>
      <p className="mt-2 text-sm text-[#9a9aa8]">
        {mode === "register"
          ? "Demo accounts start with 10,000.00 simulated NXC. Real-money features stay locked."
          : mode === "login"
            ? "Player: player@nexora.play / Demo1234!  ·  Admin: admin@nexora.play / Admin1234!"
            : "If SMTP is not configured, a one-time demo token is shown so you can test the flow."}
      </p>
      {mode !== "forgot" ? null : <input className="nx-input mt-4" name="email" type="email" required placeholder="Email" />}
      {mode === "forgot" ? null : (
        <>
          <input className="nx-input mt-4" name="email" type="email" required placeholder="Email" />
          {mode === "register" ? <input className="nx-input mt-3" name="displayName" required placeholder="Display name" /> : null}
          {mode === "register" ? <input className="nx-input mt-3" name="dateOfBirth" type="date" required /> : null}
          {mode === "register" ? (
            <select className="nx-input mt-3" name="country" defaultValue="US">
              <option value="US">United States</option>
              <option value="GB">United Kingdom</option>
              <option value="BD">Bangladesh</option>
              <option value="OTHER">Other</option>
            </select>
          ) : null}
          <input className="nx-input mt-3" name="password" type="password" required minLength={8} placeholder="Password" />
        </>
      )}
      {error ? <p className="mt-3 text-sm text-red-400">{error}</p> : null}
      {notice ? <p className="mt-3 text-sm text-[#ffb03a]">{notice}</p> : null}
      <button className="nx-btn mt-5 w-full" disabled={pending}>
        {pending ? "Please wait..." : mode === "login" ? "Login" : mode === "register" ? "Register" : "Send reset"}
      </button>
      <div className="mt-4 flex justify-between text-sm text-[#9a9aa8]">
        {mode === "login" ? <Link href="/register">Create account</Link> : <Link href="/login">Back to login</Link>}
        {mode === "login" ? <Link href="/forgot-password">Forgot password</Link> : null}
      </div>
    </form>
  );
}

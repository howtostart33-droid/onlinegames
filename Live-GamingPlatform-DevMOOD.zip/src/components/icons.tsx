import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

function Svg(props: P) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      width="1em"
      height="1em"
      {...props}
    />
  );
}

export const Icons = {
  menu: (p: P) => (
    <Svg {...p}>
      <path d="M4 6h16M4 12h16M4 18h16" />
    </Svg>
  ),
  home: (p: P) => (
    <Svg {...p}>
      <path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z" />
    </Svg>
  ),
  star: (p: P) => (
    <Svg {...p}>
      <path d="m12 3 2.6 5.7L21 9.5l-4.5 4.2L17.7 21 12 17.8 6.3 21l1.2-7.3L3 9.5l6.4-.8z" />
    </Svg>
  ),
  crown: (p: P) => (
    <Svg {...p}>
      <path d="m3 8 4.5 4L12 5l4.5 7L21 8v10H3z" />
    </Svg>
  ),
  gift: (p: P) => (
    <Svg {...p}>
      <rect x="4" y="10" width="16" height="10" rx="1" />
      <path d="M12 10v10M4 14h16M12 10c-2-4-6-3-6 0h6m0 0c2-4 6-3 6 0h-6" />
    </Svg>
  ),
  trophy: (p: P) => (
    <Svg {...p}>
      <path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H5a3 3 0 0 0 3 5M17 6h2a3 3 0 0 1-3 5" />
    </Svg>
  ),
  megaphone: (p: P) => (
    <Svg {...p}>
      <path d="M4 10v4l10 4V6zM14 10h4l2 2-2 2h-4M7 14v4" />
    </Svg>
  ),
  wallet: (p: P) => (
    <Svg {...p}>
      <rect x="3" y="6" width="18" height="13" rx="2" />
      <path d="M16 12h4M3 10h18" />
    </Svg>
  ),
  withdraw: (p: P) => (
    <Svg {...p}>
      <path d="M12 4v12M7 11l5 5 5-5M5 20h14" />
    </Svg>
  ),
  help: (p: P) => (
    <Svg {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9a2.5 2.5 0 1 1 3.2 2.4c-.8.3-1.2.8-1.2 1.6V14M12 17h.01" />
    </Svg>
  ),
  download: (p: P) => (
    <Svg {...p}>
      <path d="M12 4v10M8 10l4 4 4-4M5 20h14" />
    </Svg>
  ),
  headset: (p: P) => (
    <Svg {...p}>
      <path d="M4 13v-1a8 8 0 0 1 16 0v1M4 13v4h3v-4zM20 13v4h-3v-4zM12 20h2" />
    </Svg>
  ),
  search: (p: P) => (
    <Svg {...p}>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4 4" />
    </Svg>
  ),
  user: (p: P) => (
    <Svg {...p}>
      <circle cx="12" cy="8" r="3.2" />
      <path d="M5 19c1.5-3.2 3.8-4.8 7-4.8S17.5 15.8 19 19" />
    </Svg>
  ),
  chevronL: (p: P) => (
    <Svg {...p}>
      <path d="m15 5-7 7 7 7" />
    </Svg>
  ),
  chevronR: (p: P) => (
    <Svg {...p}>
      <path d="m9 5 7 7-7 7" />
    </Svg>
  ),
  heart: (p: P) => (
    <Svg {...p}>
      <path d="M12 20s-7-4.4-9-9.2C1.7 7.4 4 5 6.8 5c1.7 0 3.1.9 3.7 2.2C11.1 5.9 12.5 5 14.2 5 17 5 19.3 7.4 18 10.8 16 15.6 12 20 12 20z" />
    </Svg>
  ),
  close: (p: P) => (
    <Svg {...p}>
      <path d="M6 6l12 12M18 6 6 18" />
    </Svg>
  ),
  flame: (p: P) => (
    <Svg {...p}>
      <path d="M12 3s5 4 5 9a5 5 0 1 1-8.5-3.5C9 11 11 10 12 7c0 2 2 3 2 5a2 2 0 1 1-4 0c0-3 2-6 2-9z" />
    </Svg>
  ),
  slots: (p: P) => (
    <Svg {...p}>
      <rect x="4" y="5" width="16" height="14" rx="2" />
      <path d="M8 9v6M12 9v6M16 9v6" />
    </Svg>
  ),
  live: (p: P) => (
    <Svg {...p}>
      <circle cx="12" cy="12" r="3" />
      <path d="M5 8a9 9 0 0 0 0 8M19 8a9 9 0 0 1 0 8" />
    </Svg>
  ),
  sports: (p: P) => (
    <Svg {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" />
    </Svg>
  ),
  esports: (p: P) => (
    <Svg {...p}>
      <path d="M7 15H4l1-6h4l1 3h4l1-3h4l1 6h-3M9 15v3M15 15v3" />
    </Svg>
  ),
  fish: (p: P) => (
    <Svg {...p}>
      <path d="M4 12s4-6 10-6 6 6 6 6-0 6-6 6-10-6-10-6zm12 0h.01M4 12l4 3v-6z" />
    </Svg>
  ),
  arcade: (p: P) => (
    <Svg {...p}>
      <path d="M12 4v7M9 8h6M7 20h10M8 11h8l1 9H7z" />
    </Svg>
  ),
  lottery: (p: P) => (
    <Svg {...p}>
      <rect x="4" y="7" width="16" height="11" rx="2" />
      <path d="M8 7V5h8v2M9 12h.01M12 12h.01M15 12h.01" />
    </Svg>
  ),
  hold: (p: P) => (
    <Svg {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12h8" />
    </Svg>
  ),
  top: (p: P) => (
    <Svg {...p}>
      <path d="M12 19V6M6 11l6-6 6 6" />
    </Svg>
  ),
  chat: (p: P) => (
    <Svg {...p}>
      <path d="M5 18 4 21l4-2h9a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3z" />
    </Svg>
  ),
  facebook: (p: P) => (
    <Svg {...p}>
      <path d="M14 8h3V4h-3c-2.8 0-5 2.2-5 5v3H6v4h3v6h4v-6h3l1-4h-4V9c0-.6.4-1 1-1z" />
    </Svg>
  ),
  telegram: (p: P) => (
    <Svg {...p}>
      <path d="M21 5 3 12.2l5.7 1.7L18 8l-7.4 7.6 6.4 3.4z" />
    </Svg>
  ),
  whatsapp: (p: P) => (
    <Svg {...p}>
      <path d="M5 19l1.2-4A8 8 0 1 1 12 20H5z" />
    </Svg>
  ),
  shield: (p: P) => (
    <Svg {...p}>
      <path d="M12 3 5 6v6c0 4.2 2.8 7.4 7 9 4.2-1.6 7-4.8 7-9V6z" />
    </Svg>
  ),
  grid: (p: P) => (
    <Svg {...p}>
      <rect x="4" y="4" width="7" height="7" rx="1" />
      <rect x="13" y="4" width="7" height="7" rx="1" />
      <rect x="4" y="13" width="7" height="7" rx="1" />
      <rect x="13" y="13" width="7" height="7" rx="1" />
    </Svg>
  ),
};

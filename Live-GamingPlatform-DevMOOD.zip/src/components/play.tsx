"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { GameArt } from "@/components/games";
import type { GameItem } from "@/lib/types";

type Detail = {
  game: GameItem;
  provider: { name: string; code: string; status: string; healthMessage: string | null };
  category: { name: string; slug: string; legalHold: boolean };
  favorited: boolean;
  engineRules: string | null;
  launchBlockedReason: string | null;
};

export function GameDetail({ slug }: { slug: string }) {
  const [data, setData] = useState<Detail | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch(`/api/v1/games/${slug}`)
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) setError(j.error);
        else setData(j.data);
      });
  }, [slug]);

  if (error) return <div className="nx-card p-6">{error}</div>;
  if (!data) return <div className="nx-card h-64 animate-pulse" />;

  const playable = data.game.launchKind === "original" && data.game.status === "demo";

  async function launch() {
    setBusy(true);
    setError("");
    const res = await fetch(`/api/v1/games/${slug}/launch`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ idempotencyKey: crypto.randomUUID() }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.ok) {
      setError(json.error);
      return;
    }
    window.location.href = json.data.launch.launchUrl;
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
      <div className="overflow-hidden rounded-2xl border border-[#2a2c34]">
        <div className="aspect-[3/4]">
          <GameArt game={data.game} />
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-[#ffb03a]">{data.category.name}</p>
        <h1 className="font-display text-4xl font-bold">{data.game.name}</h1>
        <p className="mt-2 text-[#9a9aa8]">{data.game.description}</p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <span className="rounded-full border border-[#2a2c34] px-3 py-1">{data.provider.name}</span>
          <span className="rounded-full border border-[#2a2c34] px-3 py-1">{data.provider.status}</span>
          <span className="rounded-full border border-[#2a2c34] px-3 py-1">{data.game.status}</span>
        </div>
        {data.engineRules ? <p className="mt-4 text-sm text-white/80">{data.engineRules}</p> : null}
        {data.launchBlockedReason ? <p className="mt-4 rounded-lg border border-[#2a2c34] bg-[#16171c] p-4 text-sm">{data.launchBlockedReason}</p> : null}
        {error ? <p className="mt-3 text-sm text-red-400">{error}</p> : null}
        <div className="mt-6 flex gap-3">
          {playable ? (
            <button type="button" className="nx-btn" disabled={busy} onClick={launch}>
              {busy ? "Opening..." : "Launch demo"}
            </button>
          ) : (
            <button type="button" className="nx-btn" disabled>
              Not launchable
            </button>
          )}
          <Link href="/games" className="nx-btn nx-btn-ghost">
            Back to lobby
          </Link>
        </div>
      </div>
    </div>
  );
}

export function PlayTable({ slug }: { slug: string }) {
  const [engine, setEngine] = useState<string | null>(null);
  const [name, setName] = useState(slug);
  const [balance, setBalance] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [bet, setBet] = useState(100);
  const [message, setMessage] = useState("Demo table. Outcomes are generated on the server.");

  useEffect(() => {
    fetch(`/api/v1/games/${slug}`)
      .then((r) => r.json())
      .then((j) => {
        if (!j.ok) setError(j.error);
        else {
          setEngine(j.data.game.engineKey);
          setName(j.data.game.name);
        }
      });
    fetch("/api/v1/me")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setBalance(j.data.wallets.demo.availableCents);
      });
  }, [slug]);

  async function place(extra: Record<string, unknown> = {}) {
    setError("");
    const res = await fetch(`/api/v1/games/${slug}/bet`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ amountCents: bet, extra, idempotencyKey: crypto.randomUUID() }),
    });
    const json = await res.json();
    if (!json.ok) {
      setError(json.error);
      return null;
    }
    setBalance(json.data.balanceCents);
    setMessage(
      json.data.result.payoutCents > 0
        ? `Simulated win ${ (json.data.result.payoutCents / 100).toFixed(2) } NXC · ${json.data.result.multiplier}x`
        : "Simulated loss. No real money was involved.",
    );
    return json.data.result as { outcome: Record<string, unknown>; payoutCents: number; multiplier: number };
  }

  if (error && !engine) return <div className="nx-card p-6">{error}</div>;
  if (!engine) return <div className="nx-card h-64 animate-pulse" />;

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-widest text-[#ffb03a]">Original demo</p>
          <h1 className="font-display text-3xl font-bold">{name}</h1>
        </div>
        <div className="text-right text-sm">
          <p className="text-[#9a9aa8]">Demo balance</p>
          <p className="text-xl font-bold text-[#e8b923]">{balance == null ? "—" : (balance / 100).toFixed(2)} NXC</p>
        </div>
      </div>
      {engine === "neon-reels" ? <Slots bet={bet} setBet={setBet} place={place} /> : null}
      {engine === "pulse-crash" ? <Crash bet={bet} setBet={setBet} place={place} /> : null}
      {engine === "lucky-dice" ? <Dice bet={bet} setBet={setBet} place={place} /> : null}
      {error ? <p className="mt-3 text-sm text-red-400">{error}</p> : null}
      <p className="mt-4 text-sm text-[#9a9aa8]">{message}</p>
      <Link href={`/games/${slug}`} className="mt-6 inline-block text-sm text-[#ff9a2e]">
        Back to game details
      </Link>
    </div>
  );
}

function BetBar({ bet, setBet }: { bet: number; setBet: (n: number) => void }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm text-[#9a9aa8]">Stake</span>
      <input
        type="range"
        min={50}
        max={5000}
        step={50}
        value={bet}
        onChange={(e) => setBet(Number(e.target.value))}
      />
      <strong>{(bet / 100).toFixed(2)} NXC</strong>
    </div>
  );
}

function Slots({
  bet,
  setBet,
  place,
}: {
  bet: number;
  setBet: (n: number) => void;
  place: (extra?: Record<string, unknown>) => Promise<{ outcome: Record<string, unknown> } | null>;
}) {
  const [reels, setReels] = useState(["star", "gold", "orange"]);
  const [spinning, setSpinning] = useState(false);
  async function spin() {
    setSpinning(true);
    const result = await place();
    setSpinning(false);
    if (result?.outcome.reels) setReels(result.outcome.reels as string[]);
  }
  return (
    <div className="nx-card p-6">
      <div className="grid grid-cols-3 gap-3">
        {reels.map((sym, i) => (
          <div key={i} className="grid aspect-square place-items-center rounded-2xl bg-black text-4xl">
            {sym === "seven" ? "7" : sym === "gold" ? "◆" : sym === "star" ? "★" : sym === "cherry" ? "●" : sym === "bar" ? "▬" : "◆"}
          </div>
        ))}
      </div>
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <BetBar bet={bet} setBet={setBet} />
        <button type="button" className="nx-btn" disabled={spinning} onClick={spin}>
          {spinning ? "Spinning..." : "Spin demo"}
        </button>
      </div>
    </div>
  );
}

function Crash({
  bet,
  setBet,
  place,
}: {
  bet: number;
  setBet: (n: number) => void;
  place: (extra?: Record<string, unknown>) => Promise<{ outcome: Record<string, unknown> } | null>;
}) {
  const [cashoutAt, setCashoutAt] = useState(2);
  const [crashAt, setCrashAt] = useState<number | null>(null);
  async function go() {
    const result = await place({ cashoutAt });
    if (result?.outcome.crashAt) setCrashAt(Number(result.outcome.crashAt));
  }
  return (
    <div className="nx-card p-6">
      <p className="font-display text-5xl font-black text-[#ff7a00]">{crashAt ? `${crashAt.toFixed(2)}x crash` : "Ready"}</p>
      <p className="mt-2 text-sm text-[#9a9aa8]">Set a cash-out multiplier. The server draws the crash point; the client never decides the result.</p>
      <div className="mt-5 flex flex-wrap items-center gap-4">
        <BetBar bet={bet} setBet={setBet} />
        <label className="text-sm">
          Cash out at
          <input className="nx-input mt-1" type="number" min={1.01} step={0.01} value={cashoutAt} onChange={(e) => setCashoutAt(Number(e.target.value))} />
        </label>
        <button type="button" className="nx-btn" onClick={go}>
          Place demo round
        </button>
      </div>
    </div>
  );
}

function Dice({
  bet,
  setBet,
  place,
}: {
  bet: number;
  setBet: (n: number) => void;
  place: (extra?: Record<string, unknown>) => Promise<{ outcome: Record<string, unknown> } | null>;
}) {
  const [roll, setRoll] = useState<number | null>(null);
  async function go(guess: "high" | "low") {
    const result = await place({ guess });
    if (result?.outcome.roll) setRoll(Number(result.outcome.roll));
  }
  return (
    <div className="nx-card p-6 text-center">
      <p className="font-display text-7xl font-black">{roll ?? "?"}</p>
      <BetBar bet={bet} setBet={setBet} />
      <div className="mt-4 flex justify-center gap-3">
        <button type="button" className="nx-btn" onClick={() => go("low")}>
          Low 1-3
        </button>
        <button type="button" className="nx-btn" onClick={() => go("high")}>
          High 4-6
        </button>
      </div>
    </div>
  );
}

import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  announcements,
  auditLogs,
  banners,
  depositRequests,
  gameCategories,
  gameFavorites,
  gameProviders,
  games,
  gameSessions,
  ledgerTransactions,
  notifications,
  passwordResetTokens,
  promotionCodes,
  promotionRedemptions,
  promotions,
  recentGames,
  responsibleGamingLimits,
  sportsEvents,
  sportsMarkets,
  supportMessages,
  supportTickets,
  systemSettings,
  userSessions,
  users,
  vipTiers,
  wallets,
  withdrawalRequests,
} from "@/db/schema";
import {
  authenticate,
  canAccessAdmin,
  clearSessionCookie,
  clientIp,
  createUserAccount,
  getSessionUser,
  isAtLeast18,
  jsonError,
  jsonOk,
  rateLimit,
  roleAllows,
  setSessionCookie,
  toPublicUser,
  writeAudit,
} from "@/lib/auth";
import { hashPassword, randomToken, sha256 } from "@/lib/crypto";
import { ENGINE_RULES, playEngine } from "@/lib/game-engine";
import { getAdapter, refreshProviderHealth } from "@/lib/providers";
import { seedIfNeeded } from "@/lib/seed";
import { getSettingsMap, socialFrom } from "@/lib/settings";
import {
  REAL_MONEY_DISABLED_REASON,
  createDemoDeposit,
  createDemoWithdrawal,
  formatCredits,
  getDemoWallet,
  listTransactions,
  postLedger,
} from "@/lib/wallet";

type Ctx = { params: Promise<{ path: string[] }> };

function routeKey(path: string[]) {
  return path.join("/");
}

async function parseBody(req: Request) {
  try {
    return (await req.json()) as Record<string, unknown>;
  } catch {
    return {};
  }
}

function str(v: unknown) {
  return typeof v === "string" ? v : "";
}

function num(v: unknown) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : NaN;
}

async function requireUser() {
  return getSessionUser();
}

async function requireStaff(min: "read" | "users" | "finance" | "catalog" | "support" | "system" = "read") {
  const session = await getSessionUser();
  if (!session || !canAccessAdmin(session.user.role) || !roleAllows(session.user.role, min)) return null;
  return session;
}

export async function GET(req: Request, ctx: Ctx) {
  const { path } = await ctx.params;
  const key = routeKey(path);
  const url = new URL(req.url);
  try {
    await seedIfNeeded();

    if (key === "bootstrap") {
      const session = await getSessionUser();
      const settings = await getSettingsMap();
      const [bannerRows, announcementRows, categoryRows, providerRows] = await Promise.all([
        db.select().from(banners).where(eq(banners.enabled, true)).orderBy(asc(banners.sortOrder)),
        db.select().from(announcements).where(eq(announcements.enabled, true)).orderBy(asc(announcements.sortOrder)),
        db.select().from(gameCategories).orderBy(asc(gameCategories.sortOrder)),
        db.select().from(gameProviders).orderBy(asc(gameProviders.name)),
      ]);
      let demoBalance = 0;
      if (session) {
        const wallet = await getDemoWallet(session.user.id);
        demoBalance = wallet?.availableCents ?? 0;
      }
      return jsonOk({
        user: session ? toPublicUser(session.user) : null,
        demoBalance,
        demoBalanceLabel: formatCredits(demoBalance),
        banners: bannerRows,
        announcements: announcementRows.map((row) => row.message),
        categories: categoryRows,
        providers: providerRows.map((row) => ({
          id: row.id,
          code: row.code,
          name: row.name,
          category: row.category,
          status: row.status,
          healthStatus: row.healthStatus,
          healthMessage: row.healthMessage,
          credentialsConfigured: row.credentialsConfigured,
          lastHealthCheck: row.lastHealthCheck,
        })),
        social: socialFrom(settings),
        realMoneyEnabled: settings.real_money_enabled === "true",
        platform: { name: settings.platform_name || "Nexora", demo: true },
      });
    }

    if (key === "me") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const wallet = await getDemoWallet(session.user.id);
      const real = await db
        .select()
        .from(wallets)
        .where(and(eq(wallets.userId, session.user.id), eq(wallets.type, "real")))
        .limit(1);
      const [limits] = await db
        .select()
        .from(responsibleGamingLimits)
        .where(eq(responsibleGamingLimits.userId, session.user.id))
        .limit(1);
      const notes = await db
        .select()
        .from(notifications)
        .where(eq(notifications.userId, session.user.id))
        .orderBy(desc(notifications.createdAt))
        .limit(20);
      const sessions = await db
        .select({
          id: userSessions.id,
          userAgent: userSessions.userAgent,
          ip: userSessions.ip,
          createdAt: userSessions.createdAt,
          expiresAt: userSessions.expiresAt,
          revokedAt: userSessions.revokedAt,
        })
        .from(userSessions)
        .where(eq(userSessions.userId, session.user.id))
        .orderBy(desc(userSessions.createdAt))
        .limit(10);
      return jsonOk({
        user: toPublicUser(session.user),
        wallets: {
          demo: wallet
            ? { currency: wallet.currency, availableCents: wallet.availableCents, status: wallet.status, simulated: true }
            : null,
          real: real[0]
            ? {
                currency: real[0].currency,
                availableCents: real[0].availableCents,
                status: real[0].status,
                lockedReason: REAL_MONEY_DISABLED_REASON,
              }
            : null,
        },
        limits,
        notifications: notes,
        sessions,
      });
    }

    if (key === "games" || key === "games/search") {
      return jsonOk(await searchGames(url, (await getSessionUser())?.user.id));
    }

    if (key.startsWith("games/") && path.length === 2) {
      const slug = path[1];
      const [game] = await db.select().from(games).where(eq(games.slug, slug)).limit(1);
      if (!game) return jsonError("Game not found.", 404);
      const [provider] = await db.select().from(gameProviders).where(eq(gameProviders.id, game.providerId)).limit(1);
      const [category] = await db.select().from(gameCategories).where(eq(gameCategories.id, game.categoryId)).limit(1);
      const session = await getSessionUser();
      let favorited = false;
      if (session) {
        const [fav] = await db
          .select()
          .from(gameFavorites)
          .where(and(eq(gameFavorites.userId, session.user.id), eq(gameFavorites.gameId, game.id)))
          .limit(1);
        favorited = Boolean(fav);
      }
      return jsonOk({
        game,
        provider,
        category,
        favorited,
        engineRules: game.engineKey ? ENGINE_RULES[game.engineKey] : null,
        launchBlockedReason:
          game.launchKind === "original"
            ? null
            : game.status === "maintenance"
              ? "This title is in maintenance."
              : provider?.credentialsConfigured
                ? "Provider credentials exist, but commercial launch is not authorized."
                : provider?.healthMessage || "Provider credentials are not configured.",
      });
    }

    if (key === "providers") {
      const rows = await db.select().from(gameProviders).orderBy(asc(gameProviders.name));
      return jsonOk(rows);
    }

    if (key === "sports") {
      const sport = url.searchParams.get("sport");
      const rows = await db
        .select()
        .from(sportsEvents)
        .where(sport ? eq(sportsEvents.sport, sport) : undefined)
        .orderBy(desc(sportsEvents.isLive), asc(sportsEvents.startAt));
      return jsonOk({
        source: "fixture",
        notice: "These events are labeled fixture data. They are not live odds from a licensed sportsbook API.",
        lastUpdatedAt: rows[0]?.lastUpdatedAt ?? null,
        events: rows,
      });
    }

    if (key.startsWith("sports/") && path.length === 2) {
      const [event] = await db.select().from(sportsEvents).where(eq(sportsEvents.id, path[1])).limit(1);
      if (!event) return jsonError("Event not found.", 404);
      const markets = await db.select().from(sportsMarkets).where(eq(sportsMarkets.eventId, event.id));
      return jsonOk({
        event,
        markets,
        source: event.dataSource,
        notice:
          event.dataSource === "fixture"
            ? "Fixture sample. Real-money bet placement is disabled. Odds are not live."
            : "Authorized sports feed.",
      });
    }

    if (key === "promotions") {
      const rows = await db.select().from(promotions).where(eq(promotions.enabled, true)).orderBy(desc(promotions.startsAt));
      const codes = await db.select().from(promotionCodes);
      return jsonOk(
        rows.map((row) => ({
          ...row,
          codes: codes.filter((code) => code.promotionId === row.id).map((code) => code.code),
        })),
      );
    }

    if (key === "vip") {
      const tiers = await db.select().from(vipTiers).orderBy(asc(vipTiers.sortOrder));
      const session = await getSessionUser();
      let wagered = 0;
      if (session) {
        const [sum] = await db
          .select({ total: sql<number>`coalesce(sum(${ledgerTransactions.amountCents}),0)` })
          .from(ledgerTransactions)
          .where(and(eq(ledgerTransactions.userId, session.user.id), eq(ledgerTransactions.type, "wager")));
        wagered = Number(sum?.total ?? 0);
      }
      const current = [...tiers].reverse().find((tier) => wagered >= tier.minWagerCents) ?? tiers[0];
      return jsonOk({ tiers, wagered, current, simulated: true });
    }

    if (key === "me/favorites") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const rows = await db
        .select({ game: games })
        .from(gameFavorites)
        .innerJoin(games, eq(games.id, gameFavorites.gameId))
        .where(eq(gameFavorites.userId, session.user.id));
      return jsonOk(rows.map((row) => row.game));
    }

    if (key === "me/transactions") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      return jsonOk(await listTransactions(session.user.id, 50));
    }

    if (key === "me/tickets") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const tickets = await db
        .select()
        .from(supportTickets)
        .where(eq(supportTickets.userId, session.user.id))
        .orderBy(desc(supportTickets.updatedAt));
      return jsonOk(tickets);
    }

    if (key.startsWith("me/tickets/") && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const [ticket] = await db
        .select()
        .from(supportTickets)
        .where(and(eq(supportTickets.id, path[2]), eq(supportTickets.userId, session.user.id)))
        .limit(1);
      if (!ticket) return jsonError("Ticket not found.", 404);
      const messages = await db
        .select()
        .from(supportMessages)
        .where(eq(supportMessages.ticketId, ticket.id))
        .orderBy(asc(supportMessages.createdAt));
      return jsonOk({ ticket, messages });
    }

    if (key === "admin/dashboard") {
      const staff = await requireStaff("read");
      if (!staff) return jsonError("Administrator access required.", 403);
      const [[userCount], [gameCount], [openTickets], [txCount], providerRows] = await Promise.all([
        db.select({ n: sql<number>`count(*)` }).from(users),
        db.select({ n: sql<number>`count(*)` }).from(games),
        db.select({ n: sql<number>`count(*)` }).from(supportTickets).where(eq(supportTickets.status, "open")),
        db.select({ n: sql<number>`count(*)` }).from(ledgerTransactions),
        db.select().from(gameProviders),
      ]);
      const recentAudit = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(8);
      return jsonOk({
        users: Number(userCount.n),
        games: Number(gameCount.n),
        openTickets: Number(openTickets.n),
        transactions: Number(txCount.n),
        providers: providerRows,
        audit: recentAudit,
      });
    }

    if (key === "admin/users") {
      const staff = await requireStaff("users");
      if (!staff) return jsonError("Administrator access required.", 403);
      const q = url.searchParams.get("q")?.trim();
      const rows = await db
        .select()
        .from(users)
        .where(q ? or(ilike(users.email, `%${q}%`), ilike(users.displayName, `%${q}%`)) : undefined)
        .orderBy(desc(users.createdAt))
        .limit(100);
      return jsonOk(
        rows.map((row) => ({
          ...toPublicUser(row),
          status: row.status,
          createdAt: row.createdAt,
          lastLoginAt: row.lastLoginAt,
        })),
      );
    }

    if (key === "admin/games") {
      const staff = await requireStaff("catalog");
      if (!staff) return jsonError("Administrator access required.", 403);
      return jsonOk(await db.select().from(games).orderBy(asc(games.sortOrder)));
    }

    if (key === "admin/providers") {
      const staff = await requireStaff("catalog");
      if (!staff) return jsonError("Administrator access required.", 403);
      await refreshProviderHealth();
      return jsonOk(await db.select().from(gameProviders));
    }

    if (key === "admin/transactions") {
      const staff = await requireStaff("finance");
      if (!staff) return jsonError("Administrator access required.", 403);
      const txs = await db.select().from(ledgerTransactions).orderBy(desc(ledgerTransactions.createdAt)).limit(100);
      const deposits = await db.select().from(depositRequests).orderBy(desc(depositRequests.createdAt)).limit(50);
      const withdrawals = await db.select().from(withdrawalRequests).orderBy(desc(withdrawalRequests.createdAt)).limit(50);
      return jsonOk({ txs, deposits, withdrawals });
    }

    if (key === "admin/tickets") {
      const staff = await requireStaff("support");
      if (!staff) return jsonError("Administrator access required.", 403);
      return jsonOk(await db.select().from(supportTickets).orderBy(desc(supportTickets.updatedAt)).limit(100));
    }

    if (key.startsWith("admin/tickets/") && path.length === 3) {
      const staff = await requireStaff("support");
      if (!staff) return jsonError("Administrator access required.", 403);
      const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, path[2])).limit(1);
      if (!ticket) return jsonError("Ticket not found.", 404);
      const messages = await db
        .select()
        .from(supportMessages)
        .where(eq(supportMessages.ticketId, ticket.id))
        .orderBy(asc(supportMessages.createdAt));
      return jsonOk({ ticket, messages });
    }

    if (key === "admin/audit-logs") {
      const staff = await requireStaff("read");
      if (!staff) return jsonError("Administrator access required.", 403);
      return jsonOk(await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(200));
    }

    if (key === "admin/settings") {
      const staff = await requireStaff("system");
      if (!staff) return jsonError("Administrator access required.", 403);
      return jsonOk(await getSettingsMap());
    }

    if (key === "admin/promotions") {
      const staff = await requireStaff("catalog");
      if (!staff) return jsonError("Administrator access required.", 403);
      return jsonOk(await db.select().from(promotions));
    }

    return jsonError("Not found.", 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Server error";
    return jsonError(message, 500);
  }
}

export async function POST(req: Request, ctx: Ctx) {
  const { path } = await ctx.params;
  const key = routeKey(path);
  const ip = clientIp(req);
  const body = await parseBody(req);
  try {
    await seedIfNeeded();

    if (key === "auth/register") {
      const rl = rateLimit(`reg:${ip}`, 8, 10 * 60_000);
      if (!rl.ok) return jsonError("Too many registration attempts. Try later.", 429);
      const email = str(body.email);
      const password = str(body.password);
      const displayName = str(body.displayName);
      if (!email || !password || !displayName) return jsonError("Email, password, and display name are required.");
      if (password.length < 8) return jsonError("Password must be at least 8 characters.");
      const user = await createUserAccount({
        email,
        password,
        displayName,
        phone: str(body.phone) || undefined,
        dateOfBirth: str(body.dateOfBirth) || undefined,
        country: str(body.country) || undefined,
        language: str(body.language) || "en",
        referredByCode: str(body.referralCode) || undefined,
      });
      const auth = await authenticate(email, password, { ip, userAgent: req.headers.get("user-agent") || undefined });
      await setSessionCookie(auth.token, auth.expiresAt);
      return jsonOk({ user: toPublicUser(user) }, 201);
    }

    if (key === "auth/login") {
      const rl = rateLimit(`login:${ip}`, 12, 10 * 60_000);
      if (!rl.ok) return jsonError("Too many login attempts. Try later.", 429);
      try {
        const auth = await authenticate(str(body.email), str(body.password), {
          ip,
          userAgent: req.headers.get("user-agent") || undefined,
        });
        await setSessionCookie(auth.token, auth.expiresAt);
        return jsonOk({ user: toPublicUser(auth.user) });
      } catch (error) {
        return jsonError(error instanceof Error ? error.message : "Login failed", 401);
      }
    }

    if (key === "auth/logout") {
      const session = await getSessionUser();
      if (session) {
        await db.update(userSessions).set({ revokedAt: new Date() }).where(eq(userSessions.id, session.session.id));
        await writeAudit(session.user.id, "auth.logout", "user", session.user.id, {}, ip);
      }
      await clearSessionCookie();
      return jsonOk({ loggedOut: true });
    }

    if (key === "auth/forgot-password") {
      const rl = rateLimit(`forgot:${ip}`, 6, 10 * 60_000);
      if (!rl.ok) return jsonError("Too many reset attempts.", 429);
      const email = str(body.email).trim().toLowerCase();
      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      const generic = { message: "If that account exists, a reset path was created." };
      if (!user) return jsonOk(generic);
      const raw = randomToken(24);
      await db.insert(passwordResetTokens).values({
        userId: user.id,
        tokenHash: sha256(raw),
        expiresAt: new Date(Date.now() + 30 * 60_000),
      });
      const smtp = process.env.SMTP_URL || process.env.EMAIL_PROVIDER;
      if (!smtp) {
        return jsonOk({
          ...generic,
          demoToken: raw,
          notice:
            "SMTP is not configured. The one-time demo token is returned so the flow can be tested. This must never happen with a production mailer enabled.",
        });
      }
      return jsonOk(generic);
    }

    if (key === "auth/reset-password") {
      const token = str(body.token);
      const password = str(body.password);
      if (!token || password.length < 8) return jsonError("Valid token and password are required.");
      const [row] = await db
        .select()
        .from(passwordResetTokens)
        .where(eq(passwordResetTokens.tokenHash, sha256(token)))
        .limit(1);
      if (!row || row.usedAt || row.expiresAt < new Date()) return jsonError("Reset token is invalid or expired.");
      await db
        .update(users)
        .set({ passwordHash: await hashPassword(password), failedLoginAttempts: 0, lockedUntil: null, updatedAt: new Date() })
        .where(eq(users.id, row.userId));
      await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, row.id));
      await writeAudit(row.userId, "auth.reset_password", "user", row.userId, {}, ip);
      return jsonOk({ reset: true });
    }

    if (key === "me/language") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const language = str(body.language) === "bn" ? "bn" : "en";
      await db.update(users).set({ language, updatedAt: new Date() }).where(eq(users.id, session.user.id));
      return jsonOk({ language });
    }

    if (key === "me/profile") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const displayName = str(body.displayName).trim() || session.user.displayName;
      const country = str(body.country) || session.user.country;
      const dateOfBirth = str(body.dateOfBirth) || session.user.dateOfBirth;
      const ageVerified = isAtLeast18(dateOfBirth);
      await db
        .update(users)
        .set({ displayName, country, dateOfBirth, ageVerified, updatedAt: new Date() })
        .where(eq(users.id, session.user.id));
      return jsonOk({ updated: true, ageVerified });
    }

    if (key === "me/verify-age") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const dateOfBirth = str(body.dateOfBirth);
      if (!isAtLeast18(dateOfBirth)) return jsonError("You must be 18 or older to use this platform.");
      await db.update(users).set({ dateOfBirth, ageVerified: true, updatedAt: new Date() }).where(eq(users.id, session.user.id));
      await writeAudit(session.user.id, "rg.age_verify", "user", session.user.id, {}, ip);
      return jsonOk({ ageVerified: true });
    }

    if (key === "me/responsible") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const action = str(body.action);
      if (action === "self-exclude") {
        const days = Math.min(365, Math.max(1, num(body.days) || 1));
        const until = new Date(Date.now() + days * 86400000);
        await db.update(users).set({ selfExcludedUntil: until, updatedAt: new Date() }).where(eq(users.id, session.user.id));
        await db.update(userSessions).set({ revokedAt: new Date() }).where(eq(userSessions.userId, session.user.id));
        await writeAudit(session.user.id, "rg.self_exclude", "user", session.user.id, { days }, ip);
        await clearSessionCookie();
        return jsonOk({ selfExcludedUntil: until.toISOString() });
      }
      if (action === "cool-off") {
        const hours = Math.min(72, Math.max(1, num(body.hours) || 24));
        const until = new Date(Date.now() + hours * 3600000);
        await db.update(users).set({ coolingOffUntil: until, updatedAt: new Date() }).where(eq(users.id, session.user.id));
        await writeAudit(session.user.id, "rg.cool_off", "user", session.user.id, { hours }, ip);
        return jsonOk({ coolingOffUntil: until.toISOString() });
      }
      if (action === "limits") {
        const [existing] = await db
          .select()
          .from(responsibleGamingLimits)
          .where(eq(responsibleGamingLimits.userId, session.user.id))
          .limit(1);
        if (existing) {
          await db
            .update(responsibleGamingLimits)
            .set({
              dailyDepositCents: num(body.dailyDepositCents) || null,
              sessionMinutes: num(body.sessionMinutes) || null,
              reminderMinutes: num(body.reminderMinutes) || 60,
              updatedAt: new Date(),
            })
            .where(eq(responsibleGamingLimits.userId, session.user.id));
        } else {
          await db.insert(responsibleGamingLimits).values({
            userId: session.user.id,
            dailyDepositCents: num(body.dailyDepositCents) || null,
            sessionMinutes: num(body.sessionMinutes) || null,
            reminderMinutes: num(body.reminderMinutes) || 60,
          });
        }
        return jsonOk({ updated: true });
      }
      if (action === "close") {
        await db.update(users).set({ status: "closed", updatedAt: new Date() }).where(eq(users.id, session.user.id));
        await db.update(userSessions).set({ revokedAt: new Date() }).where(eq(userSessions.userId, session.user.id));
        await writeAudit(session.user.id, "rg.close", "user", session.user.id, {}, ip);
        await clearSessionCookie();
        return jsonOk({ closed: true });
      }
      return jsonError("Unknown responsible gaming action.");
    }

    if (key.startsWith("me/favorites/") && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const gameId = path[2];
      const [game] = await db.select().from(games).where(eq(games.id, gameId)).limit(1);
      if (!game) return jsonError("Game not found.", 404);
      await db.insert(gameFavorites).values({ userId: session.user.id, gameId }).onConflictDoNothing();
      return jsonOk({ favorited: true });
    }

    if (key === "me/deposit") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      if (session.user.coolingOffUntil && session.user.coolingOffUntil > new Date()) {
        return jsonError("Cooling-off period is active.");
      }
      const amountCents = Math.round(num(body.amountCents));
      if (!amountCents || amountCents < 100 || amountCents > 500000) {
        return jsonError("Demo deposit must be between 1.00 and 5,000.00 NXC.");
      }
      const idempotencyKey = str(body.idempotencyKey) || `dep:${session.user.id}:${Date.now()}`;
      const posted = await createDemoDeposit(session.user.id, amountCents, idempotencyKey);
      await writeAudit(session.user.id, "wallet.demo_deposit", "ledger_transaction", posted.transaction.id, { amountCents }, ip);
      return jsonOk({ ...posted, simulated: true });
    }

    if (key === "me/withdraw") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const amountCents = Math.round(num(body.amountCents));
      if (!amountCents || amountCents < 100) return jsonError("Minimum demo withdrawal is 1.00 NXC.");
      const idempotencyKey = str(body.idempotencyKey) || `wd:${session.user.id}:${Date.now()}`;
      const posted = await createDemoWithdrawal(session.user.id, amountCents, idempotencyKey);
      await writeAudit(session.user.id, "wallet.demo_withdraw", "ledger_transaction", posted.transaction.id, { amountCents }, ip);
      return jsonOk({ ...posted, simulated: true });
    }

    if (key === "promotions/redeem") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const code = str(body.code).trim().toUpperCase();
      const [promoCode] = await db.select().from(promotionCodes).where(eq(promotionCodes.code, code)).limit(1);
      if (!promoCode || !promoCode.enabled) return jsonError("Invalid promotional code.");
      const [promo] = await db.select().from(promotions).where(eq(promotions.id, promoCode.promotionId)).limit(1);
      if (!promo || !promo.enabled || promo.startsAt > new Date() || promo.endsAt < new Date()) {
        return jsonError("Promotion is not active.");
      }
      const already = await db
        .select()
        .from(promotionRedemptions)
        .where(and(eq(promotionRedemptions.userId, session.user.id), eq(promotionRedemptions.promotionId, promo.id)));
      if (already.length >= promoCode.perUserLimit) return jsonError("You already redeemed this promotion.");
      await db.insert(promotionRedemptions).values({
        promotionId: promo.id,
        codeId: promoCode.id,
        userId: session.user.id,
      });
      let credit = null;
      if (promo.creditCents > 0) {
        credit = await postLedger({
          userId: session.user.id,
          walletType: "demo",
          type: "bonus",
          amountCents: promo.creditCents,
          idempotencyKey: `promo:${promo.id}:${session.user.id}`,
          reason: `Simulated promotion ${promo.slug}`,
          actorId: session.user.id,
        });
      }
      await writeAudit(session.user.id, "promo.redeem", "promotion", promo.id, { code }, ip);
      return jsonOk({ redeemed: true, simulated: true, credit });
    }

    if (key === "support/tickets") {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const subject = str(body.subject).trim();
      const message = str(body.message).trim();
      if (!subject || !message) return jsonError("Subject and message are required.");
      const [ticket] = await db
        .insert(supportTickets)
        .values({ userId: session.user.id, subject, priority: str(body.priority) || "normal" })
        .returning();
      await db.insert(supportMessages).values({ ticketId: ticket.id, authorId: session.user.id, body: message, fromStaff: false });
      return jsonOk({ ticket }, 201);
    }

    if (key.startsWith("support/tickets/") && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      const bodyText = str(body.message).trim();
      if (!bodyText) return jsonError("Message required.");
      const [ticket] = await db
        .select()
        .from(supportTickets)
        .where(and(eq(supportTickets.id, path[2]), eq(supportTickets.userId, session.user.id)))
        .limit(1);
      if (!ticket) return jsonError("Ticket not found.", 404);
      await db.insert(supportMessages).values({ ticketId: ticket.id, authorId: session.user.id, body: bodyText, fromStaff: false });
      await db.update(supportTickets).set({ status: "open", updatedAt: new Date() }).where(eq(supportTickets.id, ticket.id));
      return jsonOk({ sent: true });
    }

    if (path[0] === "games" && path[2] === "launch" && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      if (!session.user.ageVerified) return jsonError("Age verification is required before launching games.", 403);
      const [game] = await db.select().from(games).where(eq(games.slug, path[1])).limit(1);
      if (!game) return jsonError("Game not found.", 404);
      const [provider] = await db.select().from(gameProviders).where(eq(gameProviders.id, game.providerId)).limit(1);
      const adapter = provider ? getAdapter(provider.adapterKey) : null;
      if (!adapter) return jsonError("Provider adapter is not registered.", 503);
      const launch = await adapter.createLaunchSession({ slug: game.slug, userId: session.user.id, mode: "demo" });
      if (launch.kind === "unavailable") {
        return jsonError(launch.message, 409, { launch });
      }
      const idempotencyKey = str(body.idempotencyKey) || `launch:${session.user.id}:${game.id}:${Date.now()}`;
      await db.insert(gameSessions).values({
        userId: session.user.id,
        gameId: game.id,
        providerCode: provider?.code ?? "unknown",
        mode: "demo",
        status: "open",
        idempotencyKey,
      });
      await db.insert(recentGames).values({ userId: session.user.id, gameId: game.id });
      await db.update(games).set({ playCount: game.playCount + 1 }).where(eq(games.id, game.id));
      return jsonOk({ launch });
    }

    if (path[0] === "games" && path[2] === "bet" && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      if (session.user.coolingOffUntil && session.user.coolingOffUntil > new Date()) {
        return jsonError("Cooling-off period is active.");
      }
      const [game] = await db.select().from(games).where(eq(games.slug, path[1])).limit(1);
      if (!game || game.launchKind !== "original" || !game.engineKey) {
        return jsonError("This title has no original demo engine.");
      }
      const amountCents = Math.round(num(body.amountCents));
      const idempotencyKey = str(body.idempotencyKey);
      if (!idempotencyKey) return jsonError("Idempotency key is required.");
      const extra = (body.extra as Record<string, unknown> | undefined) ?? {};
      const result = playEngine(game.engineKey, amountCents, extra);
      const wager = await postLedger({
        userId: session.user.id,
        walletType: "demo",
        type: "wager",
        amountCents,
        idempotencyKey: `${idempotencyKey}:wager`,
        reason: `Demo wager on ${game.slug}`,
        actorId: session.user.id,
        meta: { engine: game.engineKey },
      });
      let payout = null;
      if (result.payoutCents > 0 && !wager.duplicate) {
        payout = await postLedger({
          userId: session.user.id,
          walletType: "demo",
          type: "payout",
          amountCents: result.payoutCents,
          idempotencyKey: `${idempotencyKey}:payout`,
          reason: `Demo payout on ${game.slug}`,
          actorId: session.user.id,
          meta: { outcome: result.outcome },
        });
      }
      const wallet = await getDemoWallet(session.user.id);
      return jsonOk({
        simulated: true,
        result,
        wagerDuplicate: wager.duplicate,
        payout,
        balanceCents: wallet?.availableCents ?? 0,
      });
    }

    if (path[0] === "webhooks" && path.length === 2) {
      const providerCode = path[1];
      const [provider] = await db.select().from(gameProviders).where(eq(gameProviders.code, providerCode)).limit(1);
      if (!provider) return jsonError("Unknown provider.", 404);
      const adapter = getAdapter(provider.adapterKey);
      if (!adapter) return jsonError("Adapter missing.", 503);
      const raw = JSON.stringify(body);
      const signature = req.headers.get("x-signature") || req.headers.get("x-nexora-signature");
      const idempotencyKey = str(body.idempotencyKey) || req.headers.get("idempotency-key") || sha256(raw);
      const result = await adapter.processWalletTransaction({
        payload: raw,
        signature,
        idempotencyKey,
      });
      await writeAudit(null, "provider.webhook", "provider", provider.code, { result }, ip);
      if (!result.accepted) return jsonError(result.reason, 400, { result });
      return jsonOk(result);
    }

    if (key === "admin/users/status") {
      const staff = await requireStaff("users");
      if (!staff) return jsonError("Administrator access required.", 403);
      const userId = str(body.userId);
      const status = str(body.status);
      if (!["active", "suspended", "closed", "pending_verification"].includes(status)) {
        return jsonError("Invalid status.");
      }
      await db.update(users).set({ status, updatedAt: new Date() }).where(eq(users.id, userId));
      await writeAudit(staff.user.id, "admin.user_status", "user", userId, { status }, ip);
      return jsonOk({ updated: true });
    }

    if (key === "admin/games/patch") {
      const staff = await requireStaff("catalog");
      if (!staff) return jsonError("Administrator access required.", 403);
      const id = str(body.id);
      await db
        .update(games)
        .set({
          isHot: Boolean(body.isHot),
          isRecommended: Boolean(body.isRecommended),
          isNew: Boolean(body.isNew),
          status: str(body.status) || undefined,
          updatedAt: new Date(),
        })
        .where(eq(games.id, id));
      await writeAudit(staff.user.id, "admin.game_patch", "game", id, body, ip);
      return jsonOk({ updated: true });
    }

    if (key === "admin/providers/sync") {
      const staff = await requireStaff("catalog");
      if (!staff) return jsonError("Administrator access required.", 403);
      await refreshProviderHealth();
      const rows = await db.select().from(gameProviders);
      const results = [];
      for (const row of rows) {
        const adapter = getAdapter(row.adapterKey);
        if (!adapter) continue;
        results.push({ code: row.code, ...(await adapter.syncGames()) });
      }
      await writeAudit(staff.user.id, "admin.provider_sync", "provider", null, { results }, ip);
      return jsonOk(results);
    }

    if (key === "admin/tickets/reply") {
      const staff = await requireStaff("support");
      if (!staff) return jsonError("Administrator access required.", 403);
      const ticketId = str(body.ticketId);
      const message = str(body.message).trim();
      if (!ticketId || !message) return jsonError("Ticket and message required.");
      await db.insert(supportMessages).values({ ticketId, authorId: staff.user.id, body: message, fromStaff: true });
      await db
        .update(supportTickets)
        .set({ status: str(body.status) || "pending", updatedAt: new Date() })
        .where(eq(supportTickets.id, ticketId));
      return jsonOk({ replied: true });
    }

    if (key === "admin/settings") {
      const staff = await requireStaff("system");
      if (!staff) return jsonError("Administrator access required.", 403);
      const entries = (body.settings ?? {}) as Record<string, string>;
      if (entries.real_money_enabled === "true") {
        return jsonError("Real-money mode cannot be enabled from this panel until legal authorization is documented.");
      }
      for (const [k, v] of Object.entries(entries)) {
        if (typeof v !== "string") continue;
        await db
          .insert(systemSettings)
          .values({ key: k, value: v })
          .onConflictDoUpdate({
            target: systemSettings.key,
            set: { value: v, updatedAt: new Date() },
          });
      }
      await writeAudit(staff.user.id, "admin.settings", "system", null, { keys: Object.keys(entries) }, ip);
      return jsonOk(await getSettingsMap());
    }

    return jsonError("Not found.", 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Server error";
    return jsonError(message, 400);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { path } = await ctx.params;
  const key = routeKey(path);
  try {
    if (key.startsWith("me/favorites/") && path.length === 3) {
      const session = await requireUser();
      if (!session) return jsonError("Authentication required.", 401);
      await db
        .delete(gameFavorites)
        .where(and(eq(gameFavorites.userId, session.user.id), eq(gameFavorites.gameId, path[2])));
      return jsonOk({ favorited: false });
    }
    return jsonError("Not found.", 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Server error";
    return jsonError(message, 400);
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  return POST(req, ctx);
}

async function searchGames(url: URL, userId?: string) {
  const q = url.searchParams.get("q")?.trim() ?? "";
  const category = url.searchParams.get("category") ?? "";
  const provider = url.searchParams.get("provider") ?? "";
  const sort = url.searchParams.get("sort") ?? "popular";
  const filter = url.searchParams.get("filter") ?? "";
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
  const pageSize = Math.min(48, Math.max(8, Number(url.searchParams.get("pageSize") ?? "24") || 24));

  const conditions = [];
  if (q) {
    conditions.push(or(ilike(games.name, `%${q}%`), ilike(games.slug, `%${q}%`)));
  }
  if (category && category !== "hot" && category !== "recommended") {
    const [cat] = await db.select().from(gameCategories).where(eq(gameCategories.slug, category)).limit(1);
    if (cat) conditions.push(eq(games.categoryId, cat.id));
  }
  if (provider) {
    const [prov] = await db.select().from(gameProviders).where(eq(gameProviders.code, provider)).limit(1);
    if (prov) conditions.push(eq(games.providerId, prov.id));
  }
  if (filter === "new") conditions.push(eq(games.isNew, true));
  if (filter === "hot" || category === "hot") conditions.push(eq(games.isHot, true));
  if (filter === "recommended" || category === "recommended") conditions.push(eq(games.isRecommended, true));

  let favoriteGameIds: string[] = [];
  if (filter === "favorites" && userId) {
    const favs = await db.select().from(gameFavorites).where(eq(gameFavorites.userId, userId));
    favoriteGameIds = favs.map((row) => row.gameId);
  }

  const where = conditions.length ? and(...conditions) : undefined;
  const order = sort === "new" ? desc(games.createdAt) : sort === "name" ? asc(games.name) : desc(games.playCount);

  const all = await db.select().from(games).where(where).orderBy(order);

  let rows = all;
  if (filter === "favorites") rows = rows.filter((row) => favoriteGameIds.includes(row.id));
  if (filter === "recent" && userId) {
    const recents = await db
      .select()
      .from(recentGames)
      .where(eq(recentGames.userId, userId))
      .orderBy(desc(recentGames.playedAt))
      .limit(40);
    const ids = recents.map((row) => row.gameId);
    rows = rows.filter((row) => ids.includes(row.id)).sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id));
  }

  const providers = await db.select().from(gameProviders);
  const categories = await db.select().from(gameCategories);
  const providerMap = Object.fromEntries(providers.map((row) => [row.id, row]));
  const categoryMap = Object.fromEntries(categories.map((row) => [row.id, row]));
  const total = rows.length;
  const slice = rows.slice((page - 1) * pageSize, page * pageSize);

  let favorited = new Set<string>();
  if (userId) {
    const favs = await db.select().from(gameFavorites).where(eq(gameFavorites.userId, userId));
    favorited = new Set(favs.map((row) => row.gameId));
  }

  return {
    total,
    page,
    pageSize,
    items: slice.map((game) => ({
      ...game,
      provider: providerMap[game.providerId]
        ? {
            code: providerMap[game.providerId].code,
            name: providerMap[game.providerId].name,
            status: providerMap[game.providerId].status,
          }
        : null,
      category: categoryMap[game.categoryId]
        ? {
            slug: categoryMap[game.categoryId].slug,
            name: categoryMap[game.categoryId].name,
            legalHold: categoryMap[game.categoryId].legalHold,
          }
        : null,
      favorited: favorited.has(game.id),
    })),
  };
}

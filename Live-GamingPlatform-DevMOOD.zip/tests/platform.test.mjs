import assert from "node:assert/strict";
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import test from "node:test";

function hmacSha256(secret, payload) {
  return createHmac("sha256", secret).update(payload).digest("hex");
}

function safeEqual(a, b) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function verifyWebhookSignature(secret, payload, signature) {
  if (!secret) return { ok: false, reason: "missing_provider_secret" };
  if (!signature) return { ok: false, reason: "missing_signature" };
  const expected = hmacSha256(secret, payload);
  if (!safeEqual(expected, signature)) return { ok: false, reason: "invalid_signature" };
  return { ok: true };
}

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

function verifyPassword(password, stored) {
  const [salt, hex] = stored.split(":");
  const derived = scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(hex, "hex");
  return storedBuf.length === derived.length && timingSafeEqual(storedBuf, derived);
}

test("webhook signatures reject missing secrets and bad HMAC", () => {
  const payload = JSON.stringify({ amount: 100, idempotencyKey: "abc" });
  assert.equal(verifyWebhookSignature("", payload, "abc").ok, false);
  assert.equal(verifyWebhookSignature("secret", payload, null).reason, "missing_signature");
  const good = hmacSha256("secret", payload);
  assert.equal(verifyWebhookSignature("secret", payload, good).ok, true);
  assert.equal(verifyWebhookSignature("secret", payload, "00".repeat(32)).ok, false);
});

test("password hashes are salted and verifiable", () => {
  const stored = hashPassword("Demo1234!");
  assert.equal(verifyPassword("Demo1234!", stored), true);
  assert.equal(verifyPassword("wrong", stored), false);
});

test("idempotency keys collide only when identical", () => {
  const seen = new Set();
  const key = "promo:welcome:user-1";
  assert.equal(seen.has(key), false);
  seen.add(key);
  assert.equal(seen.has(key), true);
});

test("staff roles cannot be assumed from a client flag", () => {
  const roleAllows = (role, action) => {
    if (role === "super_admin") return true;
    if (role === "analyst") return action === "read";
    if (role === "support") return action === "read" || action === "support" || action === "users";
    if (role === "finance") return action === "read" || action === "finance";
    if (role === "operations") return action !== "system";
    return false;
  };
  assert.equal(roleAllows("user", "finance"), false);
  assert.equal(roleAllows("analyst", "users"), false);
  assert.equal(roleAllows("finance", "finance"), true);
  assert.equal(roleAllows("support", "system"), false);
});
